package com.example.audio

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AudioAlertManager(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.Default)
    var isSoundEnabled: Boolean = true
    var isVibrationEnabled: Boolean = true

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT)
                .build()

            // High Priority Channel for New Incoming Orders
            val newOrderChannel = NotificationChannel(
                CHANNEL_NEW_ORDERS,
                "Incoming Customer Orders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Loud audio and vibration alerts for incoming orders requiring kitchen acceptance"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(soundUri, audioAttributes)
            }

            // Standard Priority Channel for Rider & Completion Updates
            val updatesChannel = NotificationChannel(
                CHANNEL_UPDATES,
                "Rider & Order Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Status updates for rider assignment, arrival, and delivery completion"
            }

            notificationManager.createNotificationChannel(newOrderChannel)
            notificationManager.createNotificationChannel(updatesChannel)
        }
    }

    fun playNewOrderAlert() {
        if (!isSoundEnabled && !isVibrationEnabled) return

        scope.launch {
            if (isVibrationEnabled) {
                triggerVibration()
            }
            if (isSoundEnabled) {
                try {
                    val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    val ringtone = RingtoneManager.getRingtone(context, notificationUri)
                    ringtone?.play()
                } catch (_: Exception) {
                    playToneSequence()
                }
            }
        }
    }

    fun postNotification(notificationId: Int, title: String, message: String, isUrgent: Boolean = false) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        try {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

            val channelId = if (isUrgent) CHANNEL_NEW_ORDERS else CHANNEL_UPDATES
            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.quick_eats_icon)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(if (isUrgent) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)

            notificationManager.notify(notificationId, builder.build())
        } catch (_: Exception) {}
    }

    fun playToneSequence() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 95)
            toneGen.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)
            Thread.sleep(450)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
            toneGen.release()
        } catch (_: Exception) {}
    }

    fun playStatusChangeSound() {
        if (!isSoundEnabled) return
        scope.launch {
            try {
                val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 75)
                toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 200)
                toneGen.release()
            } catch (_: Exception) {}
        }
    }

    private fun triggerVibration() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            vibrator?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 300, 200, 300)
                    val amplitudes = intArrayOf(0, 255, 0, 255)
                    val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
                    it.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(longArrayOf(0, 300, 200, 300), -1)
                }
            }
        } catch (_: Exception) {}
    }

    companion object {
        const val CHANNEL_NEW_ORDERS = "quickeats_channel_new_orders"
        const val CHANNEL_UPDATES = "quickeats_channel_updates"
    }
}
