package com.example.auth

import com.example.data.SupabaseConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

sealed class AuthResult {
    data class Success(val session: VendorSession) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

sealed class RecoveryResult {
    data class Success(val message: String) : RecoveryResult()
    data class Error(val message: String) : RecoveryResult()
}

class SupabaseAuthService(
    private val client: OkHttpClient = OkHttpClient()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun signInWithEmail(
        config: SupabaseConfig,
        email: String,
        password: String
    ): AuthResult = withContext(Dispatchers.IO) {
        if (!config.isConfigured) {
            return@withContext AuthResult.Error(
                "Supabase URL or Anon Key is missing. Please configure backend credentials in Settings."
            )
        }

        try {
            val url = "${config.cleanUrl}/auth/v1/token?grant_type=password"
            val bodyJson = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Content-Type", "application/json")
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val jsonObj = JSONObject(responseBody)
                    val accessToken = jsonObj.optString("access_token", "")
                    val refreshToken = jsonObj.optString("refresh_token", "")
                    val userObj = jsonObj.optJSONObject("user")
                    val userId = userObj?.optString("id", "") ?: ""
                    val userEmail = userObj?.optString("email", email) ?: email

                    val session = VendorSession(
                        accessToken = accessToken,
                        refreshToken = refreshToken,
                        userId = userId,
                        email = userEmail,
                        restaurantId = "", // resolved via API client
                        restaurantName = ""
                    )
                    AuthResult.Success(session)
                } else {
                    val errorMsg = try {
                        val errObj = JSONObject(responseBody)
                        errObj.optString("error_description", errObj.optString("msg", "Invalid email or password."))
                    } catch (_: Exception) {
                        "Authentication failed (${response.code})."
                    }
                    AuthResult.Error(errorMsg)
                }
            }
        } catch (e: Exception) {
            AuthResult.Error("Network error: ${e.localizedMessage ?: "Unable to connect to Supabase auth service."}")
        }
    }

    suspend fun signUpWithEmail(
        config: SupabaseConfig,
        email: String,
        password: String
    ): AuthResult = withContext(Dispatchers.IO) {
        if (!config.isConfigured) {
            return@withContext AuthResult.Error(
                "Supabase URL or Anon Key is missing. Please configure backend credentials in Settings."
            )
        }

        try {
            val url = "${config.cleanUrl}/auth/v1/signup"
            val bodyJson = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Content-Type", "application/json")
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val jsonObj = JSONObject(responseBody)
                    val accessToken = jsonObj.optString("access_token", "")
                    val refreshToken = jsonObj.optString("refresh_token", "")
                    val userObj = jsonObj.optJSONObject("user")
                    val userId = userObj?.optString("id", "") ?: ""
                    val userEmail = userObj?.optString("email", email) ?: email

                    if (accessToken.isNotBlank()) {
                        val session = VendorSession(
                            accessToken = accessToken,
                            refreshToken = refreshToken,
                            userId = userId,
                            email = userEmail,
                            restaurantId = "",
                            restaurantName = ""
                        )
                        AuthResult.Success(session)
                    } else {
                        AuthResult.Error("Account created! If email confirmation is enabled, please verify your email before logging in.")
                    }
                } else {
                    val errorMsg = try {
                        val errObj = JSONObject(responseBody)
                        errObj.optString("error_description", errObj.optString("msg", "Sign up failed."))
                    } catch (_: Exception) {
                        "Sign up failed (${response.code})."
                    }
                    AuthResult.Error(errorMsg)
                }
            }
        } catch (e: Exception) {
            AuthResult.Error("Network error: ${e.localizedMessage ?: "Unable to connect to Supabase."}")
        }
    }

    suspend fun recoverPassword(
        config: SupabaseConfig,
        email: String
    ): RecoveryResult = withContext(Dispatchers.IO) {
        if (!config.isConfigured) {
            return@withContext RecoveryResult.Error("Supabase backend is not configured.")
        }

        try {
            val url = "${config.cleanUrl}/auth/v1/recover"
            val bodyJson = JSONObject().apply {
                put("email", email.trim())
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Content-Type", "application/json")
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    RecoveryResult.Success("Password recovery instructions have been sent to $email.")
                } else {
                    val errorBody = response.body?.string() ?: ""
                    val msg = try {
                        JSONObject(errorBody).optString("msg", "Unable to send recovery email.")
                    } catch (_: Exception) {
                        "Error sending recovery email (${response.code})."
                    }
                    RecoveryResult.Error(msg)
                }
            }
        } catch (e: Exception) {
            RecoveryResult.Error("Network error: ${e.localizedMessage ?: "Could not reach server."}")
        }
    }
}
