package com.example.auth

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VendorSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String,
    val restaurantId: String,
    val restaurantName: String
)

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("quickeats_vendor_session", Context.MODE_PRIVATE)

    private val _session = MutableStateFlow<VendorSession?>(loadSession())
    val session: StateFlow<VendorSession?> = _session.asStateFlow()

    fun isLoggedIn(): Boolean {
        return _session.value != null && _session.value!!.accessToken.isNotBlank()
    }

    private fun loadSession(): VendorSession? {
        val token = prefs.getString(KEY_ACCESS_TOKEN, null) ?: return null
        val refresh = prefs.getString(KEY_REFRESH_TOKEN, "") ?: ""
        val userId = prefs.getString(KEY_USER_ID, "") ?: ""
        val email = prefs.getString(KEY_EMAIL, "") ?: ""
        val restaurantId = prefs.getString(KEY_RESTAURANT_ID, "") ?: ""
        val restaurantName = prefs.getString(KEY_RESTAURANT_NAME, "") ?: ""

        if (token.isBlank() || userId.isBlank()) return null

        return VendorSession(
            accessToken = token,
            refreshToken = refresh,
            userId = userId,
            email = email,
            restaurantId = restaurantId,
            restaurantName = restaurantName
        )
    }

    fun saveSession(session: VendorSession) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, session.accessToken)
            .putString(KEY_REFRESH_TOKEN, session.refreshToken)
            .putString(KEY_USER_ID, session.userId)
            .putString(KEY_EMAIL, session.email)
            .putString(KEY_RESTAURANT_ID, session.restaurantId)
            .putString(KEY_RESTAURANT_NAME, session.restaurantName)
            .apply()
        _session.value = session
    }

    fun updateRestaurant(restaurantId: String, restaurantName: String) {
        val current = _session.value ?: return
        val updated = current.copy(restaurantId = restaurantId, restaurantName = restaurantName)
        prefs.edit()
            .putString(KEY_RESTAURANT_ID, restaurantId)
            .putString(KEY_RESTAURANT_NAME, restaurantName)
            .apply()
        _session.value = updated
    }

    fun clearSession() {
        prefs.edit().clear().apply()
        _session.value = null
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_EMAIL = "email"
        private const val KEY_RESTAURANT_ID = "restaurant_id"
        private const val KEY_RESTAURANT_NAME = "restaurant_name"
    }
}
