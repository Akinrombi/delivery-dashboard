package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.audio.AudioAlertManager
import com.example.auth.SessionManager
import com.example.auth.SupabaseAuthService
import com.example.data.SupabaseApiClient
import com.example.data.VendorRepository
import com.example.ui.components.NotificationSheet
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EarningsScreen
import com.example.ui.screens.MenuScreen
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.StoreScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.QuickEatsTheme
import com.example.ui.theme.QuickEatsYellowContainer
import com.example.ui.theme.QuickEatsYellowDark
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel

enum class VendorNavDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    ORDERS("Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong),
    MENU("Menu", Icons.Filled.RestaurantMenu, Icons.Outlined.RestaurantMenu),
    EARNINGS("Earnings", Icons.Filled.AttachMoney, Icons.Outlined.AttachMoney),
    STORE("Store", Icons.Filled.Storefront, Icons.Outlined.Storefront)
}

class MainActivity : ComponentActivity() {

    private lateinit var sessionManager: SessionManager
    private lateinit var authService: SupabaseAuthService
    private lateinit var apiClient: SupabaseApiClient
    private lateinit var audioAlertManager: AudioAlertManager
    private lateinit var repository: VendorRepository
    private lateinit var viewModel: VendorViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        sessionManager = SessionManager(applicationContext)
        authService = SupabaseAuthService()
        apiClient = SupabaseApiClient()
        audioAlertManager = AudioAlertManager(applicationContext)

        repository = VendorRepository(
            context = applicationContext,
            sessionManager = sessionManager,
            authService = authService,
            apiClient = apiClient,
            audioAlertManager = audioAlertManager
        )

        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return VendorViewModel(repository, audioAlertManager) as T
            }
        }
        viewModel = ViewModelProvider(this, factory)[VendorViewModel::class.java]

        setContent {
            QuickEatsTheme {
                val session by viewModel.session.collectAsState()
                val isSandbox by viewModel.isSandboxMode.collectAsState()

                if (session == null && !isSandbox) {
                    LoginScreen(viewModel = viewModel)
                } else {
                    QuickEatsVendorApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun QuickEatsVendorApp(viewModel: VendorViewModel) {
    var currentDestination by remember { mutableStateOf(VendorNavDestination.DASHBOARD) }
    var showNotificationSheet by remember { mutableStateOf(false) }

    val pendingOrders by viewModel.pendingOrders.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val isSandbox by viewModel.isSandboxMode.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            if (isSandbox) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(QuickEatsYellowContainer)
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = QuickEatsYellowDark, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SANDBOX PREVIEW MODE (Isolated)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = DarkSlate,
                                fontSize = 11.sp
                            )
                        }

                        Text(
                            text = "Log In",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = QuickEatsOrangeDark,
                            modifier = Modifier.clickable { viewModel.logout() }
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardWhite,
                contentColor = DarkSlate,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("vendor_bottom_nav")
            ) {
                VendorNavDestination.values().forEach { destination ->
                    val isSelected = currentDestination == destination

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            if (destination == VendorNavDestination.ORDERS && pendingOrders.isNotEmpty()) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = QuickEatsOrange,
                                            contentColor = CardWhite
                                        ) {
                                            Text("${pendingOrders.size}", fontSize = 10.sp)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = destination.title,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = destination.title,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = QuickEatsOrangeDark,
                            selectedTextColor = QuickEatsOrangeDark,
                            unselectedIconColor = MutedSlate,
                            unselectedTextColor = MutedSlate,
                            indicatorColor = SurfaceSlate
                        ),
                        modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(SurfaceSlate)
        ) {
            when (currentDestination) {
                VendorNavDestination.DASHBOARD -> {
                    DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToOrders = { currentDestination = VendorNavDestination.ORDERS },
                        onOpenNotifications = { showNotificationSheet = true }
                    )
                }
                VendorNavDestination.ORDERS -> {
                    OrdersScreen(viewModel = viewModel)
                }
                VendorNavDestination.MENU -> {
                    MenuScreen(viewModel = viewModel)
                }
                VendorNavDestination.EARNINGS -> {
                    EarningsScreen(viewModel = viewModel)
                }
                VendorNavDestination.STORE -> {
                    StoreScreen(viewModel = viewModel)
                }
            }
        }
    }

    if (showNotificationSheet) {
        NotificationSheet(
            notifications = notifications,
            onDismiss = { showNotificationSheet = false },
            onMarkRead = { id -> viewModel.markNotificationRead(id) },
            onClearAll = { viewModel.clearAllNotifications() }
        )
    }
}
