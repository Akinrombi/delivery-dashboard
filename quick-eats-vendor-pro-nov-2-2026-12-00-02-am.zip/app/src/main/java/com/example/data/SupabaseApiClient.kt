package com.example.data

import com.example.model.MenuItem
import com.example.model.MenuCategory
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.PayoutTransaction
import com.example.model.RiderInfo
import com.example.model.RiderStatus
import com.example.model.StoreStatus
import com.example.model.VendorProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SupabaseApiClient(
    private val client: OkHttpClient = OkHttpClient()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchVendorRestaurant(
        config: SupabaseConfig,
        accessToken: String,
        userId: String
    ): Result<VendorProfile> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || accessToken.isBlank()) {
            return@withContext Result.failure(Exception("Supabase backend or auth token missing"))
        }

        try {
            // First attempt to query restaurants where owner_id = userId
            val url = "${config.cleanUrl}/rest/v1/restaurants?owner_id=eq.$userId&select=*"
            val request = buildAuthenticatedGet(url, config, accessToken)

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    if (array.length() > 0) {
                        val obj = array.getJSONObject(0)
                        return@withContext Result.success(parseVendorProfile(obj))
                    }
                }
            }

            // Fallback attempt: query vendors where auth_user_id = userId
            val fallbackUrl = "${config.cleanUrl}/rest/v1/vendors?auth_user_id=eq.$userId&select=*"
            val fallbackRequest = buildAuthenticatedGet(fallbackUrl, config, accessToken)

            client.newCall(fallbackRequest).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    if (array.length() > 0) {
                        val obj = array.getJSONObject(0)
                        return@withContext Result.success(parseVendorProfile(obj))
                    }
                }
            }

            Result.failure(Exception("No restaurant record linked to this vendor account."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchOrders(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String
    ): Result<List<Order>> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) {
            return@withContext Result.failure(Exception("Not connected to live backend"))
        }

        try {
            val url = "${config.cleanUrl}/rest/v1/orders?restaurant_id=eq.$restaurantId&order=created_at.desc&select=*"
            val request = buildAuthenticatedGet(url, config, accessToken)

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Failed to fetch orders: code ${response.code}"))
                }

                val array = JSONArray(body)
                val orders = mutableListOf<Order>()
                val orderIds = mutableListOf<String>()

                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.optString("id", "")
                    if (id.isNotBlank()) orderIds.add(id)
                }

                // Batch fetch order items
                val itemsMap = if (orderIds.isNotEmpty()) {
                    fetchOrderItemsBatch(config, accessToken, orderIds)
                } else emptyMap()

                // Batch fetch real riders if assigned
                val riderIds = mutableSetOf<String>()
                for (i in 0 until array.length()) {
                    val rId = array.getJSONObject(i).optString("rider_id", "")
                    if (rId.isNotBlank() && rId != "null") riderIds.add(rId)
                }
                val ridersMap = if (riderIds.isNotEmpty()) {
                    fetchRidersBatch(config, accessToken, riderIds.toList())
                } else emptyMap()

                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val id = obj.optString("id", "")
                    val orderNum = obj.optString("order_number", "#QE-${id.takeLast(4)}")
                    val custName = obj.optString("customer_name", "Customer")
                    val custPhone = obj.optString("customer_phone", "")
                    val address = obj.optString("delivery_address", "")
                    val statusStr = obj.optString("status", "pending")
                    val subtotal = obj.optDouble("subtotal", 0.0)
                    val deliveryFee = obj.optDouble("delivery_fee", 1200.0)
                    val tax = obj.optDouble("tax", 450.0)
                    val platformFee = obj.optDouble("platform_fee", subtotal * 0.15)
                    val vendorEarnings = obj.optDouble("restaurant_earnings", subtotal - platformFee)
                    val notes = obj.optString("customer_notes", obj.optString("customer_note", ""))
                    val prepTime = obj.optInt("prep_time_minutes", 20)
                    val createdAtStr = obj.optString("created_at", "")
                    val createdAt = parseTimestamp(createdAtStr)
                    val riderId = obj.optString("rider_id", "")
                    val rider = ridersMap[riderId]
                    val cancellationReason = obj.optString("cancellation_reason", null)

                    val items = itemsMap[id] ?: emptyList()

                    orders.add(
                        Order(
                            id = id,
                            orderNumber = orderNum,
                            customerName = custName,
                            customerPhone = custPhone,
                            deliveryAddress = address,
                            status = OrderStatus.fromApi(statusStr),
                            items = items,
                            subtotal = subtotal,
                            deliveryFee = deliveryFee,
                            tax = tax,
                            platformFee = platformFee,
                            vendorEarnings = vendorEarnings,
                            customerNote = notes,
                            createdAt = createdAt,
                            prepTimeMinutes = prepTime,
                            rider = rider,
                            cancellationReason = if (cancellationReason == "null") null else cancellationReason
                        )
                    )
                }

                Result.success(orders)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchOrderItemsBatch(
        config: SupabaseConfig,
        accessToken: String,
        orderIds: List<String>
    ): Map<String, List<OrderItem>> {
        val map = mutableMapOf<String, MutableList<OrderItem>>()
        try {
            val idsParam = orderIds.joinToString(",")
            val url = "${config.cleanUrl}/rest/v1/order_items?order_id=in.($idsParam)&select=*"
            val request = buildAuthenticatedGet(url, config, accessToken)

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val orderId = obj.optString("order_id", "")
                        val item = OrderItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            menuItemId = obj.optString("menu_item_id", ""),
                            name = obj.optString("item_name", obj.optString("name", "Food Item")),
                            quantity = obj.optInt("quantity", 1),
                            unitPrice = obj.optDouble("unit_price", obj.optDouble("price", 0.0)),
                            options = obj.optString("options_note", obj.optString("options", "")),
                            imageUrl = obj.optString("image_url", "")
                        )
                        map.getOrPut(orderId) { mutableListOf() }.add(item)
                    }
                }
            }
        } catch (_: Exception) {}
        return map
    }

    private fun fetchRidersBatch(
        config: SupabaseConfig,
        accessToken: String,
        riderIds: List<String>
    ): Map<String, RiderInfo> {
        val map = mutableMapOf<String, RiderInfo>()
        try {
            val idsParam = riderIds.joinToString(",")
            val url = "${config.cleanUrl}/rest/v1/riders?id=in.($idsParam)&select=*"
            val request = buildAuthenticatedGet(url, config, accessToken)

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val id = obj.optString("id", "")
                        val name = obj.optString("full_name", obj.optString("name", "QuickEats Rider"))
                        val phone = obj.optString("phone_number", obj.optString("phone", ""))
                        val vehicleType = obj.optString("vehicle_type", "Motorcycle")
                        val plate = obj.optString("vehicle_plate", "")
                        val statusStr = obj.optString("status", "assigned")
                        val status = when (statusStr.lowercase()) {
                            "at_restaurant" -> RiderStatus.AT_RESTAURANT
                            "picked_up" -> RiderStatus.PICKED_UP
                            "delivered" -> RiderStatus.DELIVERED
                            else -> RiderStatus.ASSIGNED
                        }

                        map[id] = RiderInfo(
                            id = id,
                            name = name,
                            phone = phone,
                            vehicleType = vehicleType,
                            vehiclePlate = plate,
                            status = status,
                            etaMinutes = 5
                        )
                    }
                }
            }
        } catch (_: Exception) {}
        return map
    }

    suspend fun updateOrderStatus(
        config: SupabaseConfig,
        accessToken: String,
        orderId: String,
        status: OrderStatus,
        prepTimeMinutes: Int? = null,
        cancellationReason: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || orderId.isBlank()) {
            return@withContext Result.failure(Exception("Backend not configured"))
        }

        try {
            val url = "${config.cleanUrl}/rest/v1/orders?id=eq.$orderId"
            val bodyJson = JSONObject().apply {
                put("status", status.apiValue)
                if (prepTimeMinutes != null) put("prep_time_minutes", prepTimeMinutes)
                if (cancellationReason != null) put("cancellation_reason", cancellationReason)
                put("updated_at", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date()))
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .patch(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(Unit)
                } else {
                    Result.failure(Exception("Status update failed: code ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchMenu(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String
    ): Result<Pair<List<MenuCategory>, List<MenuItem>>> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) {
            return@withContext Result.failure(Exception("Backend not configured"))
        }

        try {
            // Fetch categories
            val catUrl = "${config.cleanUrl}/rest/v1/menu_categories?restaurant_id=eq.$restaurantId&order=display_order.asc&select=*"
            val catRequest = buildAuthenticatedGet(catUrl, config, accessToken)

            val categories = mutableListOf<MenuCategory>()
            client.newCall(catRequest).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    categories.add(MenuCategory("cat-all", "All Items", 0))
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        categories.add(
                            MenuCategory(
                                id = obj.optString("id", ""),
                                name = obj.optString("name", "Category"),
                                itemCount = 0
                            )
                        )
                    }
                }
            }

            // Fetch items
            val itemUrl = "${config.cleanUrl}/rest/v1/menu_items?restaurant_id=eq.$restaurantId&order=name.asc&select=*"
            val itemRequest = buildAuthenticatedGet(itemUrl, config, accessToken)

            val items = mutableListOf<MenuItem>()
            client.newCall(itemRequest).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        items.add(
                            MenuItem(
                                id = obj.optString("id", ""),
                                vendorId = restaurantId,
                                categoryId = obj.optString("category_id", "cat-all"),
                                name = obj.optString("name", ""),
                                description = obj.optString("description", ""),
                                price = obj.optDouble("price", 0.0),
                                imageUrl = obj.optString("image_url", ""),
                                isAvailable = obj.optBoolean("is_available", true),
                                isVegetarian = obj.optBoolean("is_vegetarian", false),
                                isSpicy = obj.optBoolean("is_spicy", false),
                                prepTimeMinutes = obj.optInt("prep_time_minutes", 15)
                            )
                        )
                    }
                }
            }

            Result.success(Pair(categories, items))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveMenuItem(
        config: SupabaseConfig,
        accessToken: String,
        item: MenuItem
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val bodyJson = JSONObject().apply {
                put("restaurant_id", item.vendorId)
                if (item.categoryId != "cat-all") put("category_id", item.categoryId)
                put("name", item.name)
                put("description", item.description)
                put("price", item.price)
                put("image_url", item.imageUrl)
                put("is_available", item.isAvailable)
                put("is_vegetarian", item.isVegetarian)
                put("is_spicy", item.isSpicy)
                put("prep_time_minutes", item.prepTimeMinutes)
            }.toString()

            val isExisting = item.id.isNotBlank() && !item.id.startsWith("item-")
            val url = if (isExisting) {
                "${config.cleanUrl}/rest/v1/menu_items?id=eq.${item.id}"
            } else {
                "${config.cleanUrl}/rest/v1/menu_items"
            }

            val requestBuilder = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")

            val request = if (isExisting) {
                requestBuilder.patch(bodyJson.toRequestBody(jsonMediaType)).build()
            } else {
                requestBuilder.post(bodyJson.toRequestBody(jsonMediaType)).build()
            }

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) Result.success(Unit)
                else Result.failure(Exception("Failed to save menu item (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMenuItem(
        config: SupabaseConfig,
        accessToken: String,
        itemId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || itemId.isBlank()) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val url = "${config.cleanUrl}/rest/v1/menu_items?id=eq.$itemId"
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) Result.success(Unit)
                else Result.failure(Exception("Delete failed: code ${response.code}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRestaurantStatus(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String,
        status: StoreStatus
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val url = "${config.cleanUrl}/rest/v1/restaurants?id=eq.$restaurantId"
            val bodyJson = JSONObject().apply {
                put("status", status.apiValue)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .patch(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) Result.success(Unit)
                else Result.failure(Exception("Update store status failed (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun pauseKitchenOrders(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String,
        isPaused: Boolean,
        pausedUntil: Long?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val url = "${config.cleanUrl}/rest/v1/restaurants?id=eq.$restaurantId"
            val bodyJson = JSONObject().apply {
                put("is_paused", isPaused)
                put("paused_until", pausedUntil ?: JSONObject.NULL)
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .patch(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) Result.success(Unit)
                else Result.failure(Exception("Kitchen pause update failed (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPayouts(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String
    ): Result<List<PayoutTransaction>> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val url = "${config.cleanUrl}/rest/v1/vendor_payouts?restaurant_id=eq.$restaurantId&order=created_at.desc&select=*"
            val request = buildAuthenticatedGet(url, config, accessToken)

            val list = mutableListOf<PayoutTransaction>()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    val array = JSONArray(body)
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        list.add(
                            PayoutTransaction(
                                id = obj.optString("id", ""),
                                reference = obj.optString("reference_code", "QE-PAYOUT-${obj.optString("id").takeLast(5)}"),
                                amount = obj.optDouble("amount", 0.0),
                                fee = obj.optDouble("fee", 0.0),
                                netAmount = obj.optDouble("net_amount", obj.optDouble("amount", 0.0)),
                                status = obj.optString("status", "PENDING").uppercase(),
                                date = formatShortDate(obj.optString("created_at")),
                                bankAccountLast4 = obj.optString("account_number", "4820").takeLast(4),
                                bankName = obj.optString("bank_name", "Zenith Bank")
                            )
                        )
                    }
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestPayout(
        config: SupabaseConfig,
        accessToken: String,
        restaurantId: String,
        amount: Double,
        bankAccountLast4: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (!config.isConfigured || restaurantId.isBlank()) return@withContext Result.failure(Exception("Backend not configured"))

        try {
            val url = "${config.cleanUrl}/rest/v1/vendor_payouts"
            val bodyJson = JSONObject().apply {
                put("restaurant_id", restaurantId)
                put("amount", amount)
                put("net_amount", amount)
                put("fee", 0.0)
                put("status", "pending")
                put("reference_code", "QE-PAYOUT-${(10000..99999).random()}")
                put("bank_name", "Zenith Bank")
                put("account_number", "******$bankAccountLast4")
                put("created_at", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date()))
            }.toString()

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", config.anonKey)
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json")
                .post(bodyJson.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) Result.success(Unit)
                else Result.failure(Exception("Payout request rejected (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildAuthenticatedGet(url: String, config: SupabaseConfig, token: String): Request {
        return Request.Builder()
            .url(url)
            .addHeader("apikey", config.anonKey)
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()
    }

    private fun parseVendorProfile(obj: JSONObject): VendorProfile {
        return VendorProfile(
            id = obj.optString("id", ""),
            name = obj.optString("name", "Quick Eats Restaurant"),
            description = obj.optString("description", ""),
            cuisine = obj.optString("cuisine", "Fast Food, Nigerian"),
            address = obj.optString("address", "Lagos, Nigeria"),
            phone = obj.optString("phone", ""),
            email = obj.optString("email", ""),
            rating = obj.optDouble("rating", 4.8),
            totalReviews = obj.optInt("total_reviews", 120),
            status = StoreStatus.fromApi(obj.optString("status", "open")),
            prepTimeMinutes = obj.optInt("prep_time_minutes", 20),
            commissionRatePercent = obj.optDouble("commission_rate", 15.0),
            isPaused = obj.optBoolean("is_paused", false),
            pausedUntil = if (obj.has("paused_until") && !obj.isNull("paused_until")) obj.optLong("paused_until") else null,
            logoUrl = obj.optString("logo_url", ""),
            bannerUrl = obj.optString("banner_url", "")
        )
    }

    private fun parseTimestamp(str: String): Long {
        if (str.isBlank()) return System.currentTimeMillis()
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)
            sdf.parse(str.take(19))?.time ?: System.currentTimeMillis()
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }

    private fun formatShortDate(str: String): String {
        val time = parseTimestamp(str)
        return SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date(time))
    }
}
