package com.example.data

import android.content.Context
import com.example.BuildConfig

data class SupabaseConfig(
    val url: String = "",
    val anonKey: String = "",
    val vendorId: String = ""
) {
    val cleanUrl: String
        get() = url.trim().removeSuffix("/")

    val isConfigured: Boolean
        get() = url.isNotBlank() &&
                !url.contains("your-project") &&
                anonKey.isNotBlank() &&
                !anonKey.contains("your-anon-key")

    companion object {
        private const val PREFS_NAME = "supabase_config_prefs"
        private const val KEY_URL = "saved_supabase_url"
        private const val KEY_ANON_KEY = "saved_supabase_anon_key"
        private const val KEY_VENDOR_ID = "saved_vendor_id"

        const val DEFAULT_SUPABASE_URL = "https://glkutdkwbrjpiuqcmgwe.supabase.co"
        const val DEFAULT_SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imdsa3V0ZGt3YnJqcGl1cWNtZ3dlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk5NzU3MTMsImV4cCI6MjEwNTU1MTcxM30.f2SgZJvP681imm0Qe1fKsATnCk_86z2guwvZWASXoZM"
        const val DEFAULT_VENDOR_ID_VALUE = "vendor-quick-001"

        fun load(context: Context): SupabaseConfig {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

            var url = prefs.getString(KEY_URL, null)
            var key = prefs.getString(KEY_ANON_KEY, null)
            var vId = prefs.getString(KEY_VENDOR_ID, null)

            if (url.isNullOrBlank()) {
                url = try {
                    val fieldVal = BuildConfig::class.java.getField("SUPABASE_URL").get(null) as? String
                    if (!fieldVal.isNullOrBlank() && !fieldVal.contains("your-project")) fieldVal else DEFAULT_SUPABASE_URL
                } catch (_: Exception) { DEFAULT_SUPABASE_URL }
            }

            if (key.isNullOrBlank()) {
                key = try {
                    val fieldVal = BuildConfig::class.java.getField("SUPABASE_ANON_KEY").get(null) as? String
                    if (!fieldVal.isNullOrBlank() && !fieldVal.contains("your-anon-key")) fieldVal else DEFAULT_SUPABASE_ANON_KEY
                } catch (_: Exception) { DEFAULT_SUPABASE_ANON_KEY }
            }

            if (vId.isNullOrBlank()) {
                vId = try {
                    val fieldVal = BuildConfig::class.java.getField("DEFAULT_VENDOR_ID").get(null) as? String
                    if (!fieldVal.isNullOrBlank()) fieldVal else DEFAULT_VENDOR_ID_VALUE
                } catch (_: Exception) { DEFAULT_VENDOR_ID_VALUE }
            }

            return SupabaseConfig(
                url = url ?: DEFAULT_SUPABASE_URL,
                anonKey = key ?: DEFAULT_SUPABASE_ANON_KEY,
                vendorId = vId ?: DEFAULT_VENDOR_ID_VALUE
            )
        }

        fun save(context: Context, config: SupabaseConfig) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_URL, config.url)
                .putString(KEY_ANON_KEY, config.anonKey)
                .putString(KEY_VENDOR_ID, config.vendorId)
                .apply()
        }
    }
}
