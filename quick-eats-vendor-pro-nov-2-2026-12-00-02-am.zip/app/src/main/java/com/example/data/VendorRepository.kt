package com.example.data

import android.content.Context
import com.example.audio.AudioAlertManager
import com.example.auth.AuthResult
import com.example.auth.RecoveryResult
import com.example.auth.SessionManager
import com.example.auth.SupabaseAuthService
import com.example.auth.VendorSession
import com.example.model.MenuCategory
import com.example.model.MenuItem
import com.example.model.NotificationAlert
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.PayoutTransaction
import com.example.model.RiderInfo
import com.example.model.RiderStatus
import com.example.model.StoreStatus
import com.example.model.VendorEarnings
import com.example.model.VendorProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class VendorRepository(
    private val context: Context,
    private val sessionManager: SessionManager,
    private val authService: SupabaseAuthService,
    private val apiClient: SupabaseApiClient,
    private val audioAlertManager: AudioAlertManager
) {
    private val scope = CoroutineScope(Dispatchers.IO)
    private var pollingJob: Job? = null

    private val _supabaseConfig = MutableStateFlow(SupabaseConfig.load(context))
    val supabaseConfig: StateFlow<SupabaseConfig> = _supabaseConfig.asStateFlow()

    private val _isSupabaseConnected = MutableStateFlow(false)
    val isSupabaseConnected: StateFlow<Boolean> = _isSupabaseConnected.asStateFlow()

    private val _session = MutableStateFlow(sessionManager.session.value)
    val session: StateFlow<VendorSession?> = _session.asStateFlow()

    private val _isSandboxMode = MutableStateFlow(false)
    val isSandboxMode: StateFlow<Boolean> = _isSandboxMode.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _vendorProfile = MutableStateFlow(createDefaultProfile())
    val vendorProfile: StateFlow<VendorProfile> = _vendorProfile.asStateFlow()

    private val _categories = MutableStateFlow<List<MenuCategory>>(emptyList())
    val categories: StateFlow<List<MenuCategory>> = _categories.asStateFlow()

    private val _menuItems = MutableStateFlow<List<MenuItem>>(emptyList())
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationAlert>>(emptyList())
    val notifications: StateFlow<List<NotificationAlert>> = _notifications.asStateFlow()

    private val _earnings = MutableStateFlow(
        VendorEarnings(
            todaySales = 0.0,
            weekSales = 0.0,
            monthSales = 0.0,
            totalGrossSales = 0.0,
            totalCommission = 0.0,
            netEarnings = 0.0,
            completedOrdersCount = 0,
            averageOrderValue = 0.0,
            payouts = emptyList()
        )
    )
    val earnings: StateFlow<VendorEarnings> = _earnings.asStateFlow()

    private val _pauseBanner = MutableStateFlow<String?>(null)
    val pauseBanner: StateFlow<String?> = _pauseBanner.asStateFlow()

    private val knownOrderIds = mutableSetOf<String>()

    init {
        // Auto-restore session if logged in
        if (sessionManager.isLoggedIn()) {
            _session.value = sessionManager.session.value
            _isSandboxMode.value = false
            loadAuthenticatedData()
            startRealtimePolling()
        }
    }

    fun updateSupabaseConfig(url: String, anonKey: String, vendorId: String) {
        val newCfg = SupabaseConfig(url.trim(), anonKey.trim(), vendorId.trim())
        SupabaseConfig.save(context, newCfg)
        _supabaseConfig.value = newCfg
    }

    // --- AUTHENTICATION FLOW (Phase 2) ---
    suspend fun signIn(email: String, pass: String): AuthResult {
        _isLoading.value = true
        _errorMessage.value = null

        val result = authService.signInWithEmail(_supabaseConfig.value, email, pass)
        if (result is AuthResult.Success) {
            val baseSession = result.session

            // Resolve vendor restaurant
            val restaurantResult = apiClient.fetchVendorRestaurant(
                _supabaseConfig.value,
                baseSession.accessToken,
                baseSession.userId
            )

            val fullSession = if (restaurantResult.isSuccess) {
                val profile = restaurantResult.getOrThrow()
                _vendorProfile.value = profile
                baseSession.copy(restaurantId = profile.id, restaurantName = profile.name)
            } else {
                val fallbackId = _supabaseConfig.value.vendorId.ifBlank { "vendor-${baseSession.userId.take(8)}" }
                baseSession.copy(restaurantId = fallbackId, restaurantName = "Quick Eats Kitchen")
            }

            sessionManager.saveSession(fullSession)
            _session.value = fullSession
            _isSandboxMode.value = false
            _isSupabaseConnected.value = true

            loadAuthenticatedData()
            startRealtimePolling()
        } else if (result is AuthResult.Error) {
            _errorMessage.value = result.message
        }

        _isLoading.value = false
        return result
    }

    suspend fun signUp(email: String, pass: String): AuthResult {
        _isLoading.value = true
        _errorMessage.value = null

        val result = authService.signUpWithEmail(_supabaseConfig.value, email, pass)
        if (result is AuthResult.Success) {
            val baseSession = result.session

            val restaurantResult = apiClient.fetchVendorRestaurant(
                _supabaseConfig.value,
                baseSession.accessToken,
                baseSession.userId
            )

            val fullSession = if (restaurantResult.isSuccess) {
                val profile = restaurantResult.getOrThrow()
                _vendorProfile.value = profile
                baseSession.copy(restaurantId = profile.id, restaurantName = profile.name)
            } else {
                val fallbackId = _supabaseConfig.value.vendorId.ifBlank { "vendor-${baseSession.userId.take(8)}" }
                baseSession.copy(restaurantId = fallbackId, restaurantName = "Quick Eats Kitchen")
            }

            sessionManager.saveSession(fullSession)
            _session.value = fullSession
            _isSandboxMode.value = false
            _isSupabaseConnected.value = true

            loadAuthenticatedData()
            startRealtimePolling()
        } else if (result is AuthResult.Error) {
            _errorMessage.value = result.message
        }

        _isLoading.value = false
        return result
    }

    suspend fun recoverPassword(email: String): RecoveryResult {
        return authService.recoverPassword(_supabaseConfig.value, email)
    }

    fun logout() {
        stopRealtimePolling()
        sessionManager.clearSession()
        _session.value = null
        _isSandboxMode.value = false
        _orders.value = emptyList()
        _menuItems.value = emptyList()
        _notifications.value = emptyList()
        _vendorProfile.value = createDefaultProfile()
    }

    fun enterSandboxPreviewMode() {
        stopRealtimePolling()
        _isSandboxMode.value = true
        _isSupabaseConnected.value = false
        seedSandboxData()
    }

    // --- DATA FETCHING & POLLING ---
    fun refreshData() {
        if (_isSandboxMode.value) return

        val s = _session.value ?: return
        scope.launch {
            _isLoading.value = true
            loadAuthenticatedData()
            _isLoading.value = false
        }
    }

    private fun loadAuthenticatedData() {
        val s = _session.value ?: return
        val cfg = _supabaseConfig.value

        scope.launch {
            // 1. Fetch Orders
            val ordersRes = apiClient.fetchOrders(cfg, s.accessToken, s.restaurantId)
            if (ordersRes.isSuccess) {
                val list = ordersRes.getOrThrow()
                checkForNewOrdersAndAlert(list)
                _orders.value = list
                calculateEarnings(list)
                _isSupabaseConnected.value = true
            }

            // 2. Fetch Menu
            val menuRes = apiClient.fetchMenu(cfg, s.accessToken, s.restaurantId)
            if (menuRes.isSuccess) {
                val (cats, items) = menuRes.getOrThrow()
                _categories.value = cats
                _menuItems.value = items
            }

            // 3. Fetch Payouts
            val payoutsRes = apiClient.fetchPayouts(cfg, s.accessToken, s.restaurantId)
            if (payoutsRes.isSuccess) {
                val payouts = payoutsRes.getOrThrow()
                _earnings.update { it.copy(payouts = payouts) }
            }
        }
    }

    private fun checkForNewOrdersAndAlert(newList: List<Order>) {
        val newPending = newList.filter { it.status == OrderStatus.PENDING && !knownOrderIds.contains(it.id) }
        if (newPending.isNotEmpty()) {
            newPending.forEach { order ->
                knownOrderIds.add(order.id)
                addNotification(
                    title = "New Order ${order.orderNumber}",
                    message = "${order.customerName} placed an order for ₦${String.format(Locale.US, "%,.2f", order.subtotal)}",
                    type = "NEW_ORDER",
                    orderId = order.id
                )
            }
            audioAlertManager.playNewOrderAlert()
        }
        knownOrderIds.addAll(newList.map { it.id })
    }

    private fun startRealtimePolling() {
        stopRealtimePolling()
        pollingJob = scope.launch {
            while (isActive) {
                delay(20000) // Poll every 20s
                if (sessionManager.isLoggedIn() && !_isSandboxMode.value) {
                    loadAuthenticatedData()
                }
            }
        }
    }

    private fun stopRealtimePolling() {
        pollingJob?.cancel()
        pollingJob = null
    }

    // --- ORDER ACTIONS (Guarded against duplicate acceptance) ---
    @Synchronized
    fun acceptOrder(orderId: String, prepMinutes: Int = 20) {
        val target = _orders.value.find { it.id == orderId } ?: return
        if (target.status != OrderStatus.PENDING) return // prevent duplicate acceptance

        val updated = target.copy(status = OrderStatus.PREPARING, prepTimeMinutes = prepMinutes)
        _orders.update { list -> list.map { if (it.id == orderId) updated else it } }
        audioAlertManager.playStatusChangeSound()

        addNotification(
            title = "Order Accepted (${target.orderNumber})",
            message = "Kitchen is preparing order. Estimated prep time: $prepMinutes mins.",
            type = "ORDER_ACCEPTED",
            orderId = orderId
        )

        // Sync with backend if live
        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.updateOrderStatus(
                    _supabaseConfig.value,
                    _session.value!!.accessToken,
                    orderId,
                    OrderStatus.ACCEPTED,
                    prepMinutes
                )
            }
        }
    }

    fun rejectOrder(orderId: String, reason: String) {
        val target = _orders.value.find { it.id == orderId } ?: return
        val updated = target.copy(status = OrderStatus.CANCELLED, cancellationReason = reason)
        _orders.update { list -> list.map { if (it.id == orderId) updated else it } }

        addNotification(
            title = "Order Declined (${target.orderNumber})",
            message = "Declined: $reason",
            type = "ORDER_CANCELLED",
            orderId = orderId
        )

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.updateOrderStatus(
                    _supabaseConfig.value,
                    _session.value!!.accessToken,
                    orderId,
                    OrderStatus.CANCELLED,
                    null,
                    reason
                )
            }
        }
    }

    fun markOrderReady(orderId: String) {
        val target = _orders.value.find { it.id == orderId } ?: return
        val updated = target.copy(status = OrderStatus.READY_FOR_PICKUP)
        _orders.update { list -> list.map { if (it.id == orderId) updated else it } }
        audioAlertManager.playStatusChangeSound()

        addNotification(
            title = "Order Ready (${target.orderNumber})",
            message = "Marked ready for rider collection.",
            type = "ORDER_READY",
            orderId = orderId
        )

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.updateOrderStatus(
                    _supabaseConfig.value,
                    _session.value!!.accessToken,
                    orderId,
                    OrderStatus.READY_FOR_PICKUP
                )
            }
        }
    }

    fun markOrderCompleted(orderId: String) {
        val target = _orders.value.find { it.id == orderId } ?: return
        val updated = target.copy(status = OrderStatus.COMPLETED)
        _orders.update { list -> list.map { if (it.id == orderId) updated else it } }
        audioAlertManager.playStatusChangeSound()

        addNotification(
            title = "Order Delivered (${target.orderNumber})",
            message = "Order complete! ₦${String.format(Locale.US, "%,.2f", target.vendorEarnings)} credited.",
            type = "ORDER_COMPLETED",
            orderId = orderId
        )

        calculateEarnings(_orders.value)

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.updateOrderStatus(
                    _supabaseConfig.value,
                    _session.value!!.accessToken,
                    orderId,
                    OrderStatus.COMPLETED
                )
            }
        }
    }

    // --- MENU ACTIONS ---
    fun toggleMenuItemAvailability(itemId: String, isAvailable: Boolean) {
        val item = _menuItems.value.find { it.id == itemId } ?: return
        val updated = item.copy(isAvailable = isAvailable)
        _menuItems.update { list -> list.map { if (it.id == itemId) updated else it } }

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.saveMenuItem(_supabaseConfig.value, _session.value!!.accessToken, updated)
            }
        }
    }

    fun saveMenuItem(item: MenuItem) {
        val exists = _menuItems.value.any { it.id == item.id }
        if (exists) {
            _menuItems.update { list -> list.map { if (it.id == item.id) item else it } }
        } else {
            _menuItems.update { it + item }
        }

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.saveMenuItem(_supabaseConfig.value, _session.value!!.accessToken, item)
            }
        }
    }

    fun deleteMenuItem(itemId: String) {
        _menuItems.update { list -> list.filterNot { it.id == itemId } }

        if (!_isSandboxMode.value && _session.value != null) {
            scope.launch {
                apiClient.deleteMenuItem(_supabaseConfig.value, _session.value!!.accessToken, itemId)
            }
        }
    }

    fun pauseAllItems(minutes: Int, label: String) {
        val pausedUntil = System.currentTimeMillis() + (minutes * 60 * 1000L)
        _menuItems.update { list -> list.map { it.copy(isAvailable = false) } }
        _vendorProfile.update { it.copy(isPaused = true, pausedUntil = pausedUntil) }
        _pauseBanner.value = "All items paused ($label)"

        val s = _session.value
        if (!_isSandboxMode.value && s != null) {
            scope.launch {
                apiClient.pauseKitchenOrders(_supabaseConfig.value, s.accessToken, s.restaurantId, true, pausedUntil)
            }
        }
    }

    fun restoreAllItems() {
        _menuItems.update { list -> list.map { it.copy(isAvailable = true) } }
        _vendorProfile.update { it.copy(isPaused = false, pausedUntil = null) }
        _pauseBanner.value = null

        val s = _session.value
        if (!_isSandboxMode.value && s != null) {
            scope.launch {
                apiClient.pauseKitchenOrders(_supabaseConfig.value, s.accessToken, s.restaurantId, false, null)
            }
        }
    }

    // --- STORE SETTINGS ---
    fun setStoreStatus(status: StoreStatus) {
        _vendorProfile.update { it.copy(status = status) }
        audioAlertManager.playStatusChangeSound()

        val s = _session.value
        if (!_isSandboxMode.value && s != null) {
            scope.launch {
                apiClient.updateRestaurantStatus(_supabaseConfig.value, s.accessToken, s.restaurantId, status)
            }
        }
    }

    fun updateVendorProfile(profile: VendorProfile) {
        _vendorProfile.value = profile
        // Sync with session name
        sessionManager.updateRestaurant(profile.id, profile.name)
    }

    // --- PAYOUT ACTION ---
    fun requestPayout(amount: Double) {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        val newTx = PayoutTransaction(
            id = "po-${System.currentTimeMillis() % 10000}",
            reference = "QE-PAYOUT-${(10000..99999).random()}",
            amount = amount,
            fee = 0.0,
            netAmount = amount,
            status = "PROCESSING",
            date = dateFormat.format(Date()),
            bankAccountLast4 = "4820",
            bankName = "Zenith Bank"
        )

        _earnings.update { current ->
            current.copy(payouts = listOf(newTx) + current.payouts)
        }

        addNotification(
            title = "Payout Requested",
            message = "Withdrawal of ₦${String.format(Locale.US, "%,.2f", amount)} submitted for settlement.",
            type = "PAYOUT_REQUESTED"
        )

        val s = _session.value
        if (!_isSandboxMode.value && s != null) {
            scope.launch {
                apiClient.requestPayout(_supabaseConfig.value, s.accessToken, s.restaurantId, amount, "4820")
            }
        }
    }

    // --- NOTIFICATIONS ---
    fun addNotification(title: String, message: String, type: String, orderId: String? = null) {
        val alert = NotificationAlert(
            id = UUID.randomUUID().toString(),
            title = title,
            message = message,
            type = type,
            orderId = orderId
        )
        _notifications.update { listOf(alert) + it }
    }

    fun markNotificationRead(id: String) {
        _notifications.update { list -> list.map { if (it.id == id) it.copy(isRead = true) else it } }
    }

    fun clearAllNotifications() {
        _notifications.value = emptyList()
    }

    private fun calculateEarnings(orderList: List<Order>) {
        val completed = orderList.filter { it.status == OrderStatus.COMPLETED }
        val gross = completed.sumOf { it.subtotal }
        val comm = completed.sumOf { it.platformFee }
        val net = completed.sumOf { it.vendorEarnings }
        val count = completed.size
        val aov = if (count > 0) gross / count else 0.0

        _earnings.update { current ->
            current.copy(
                todaySales = gross,
                weekSales = gross * 1.5,
                monthSales = gross * 3.8,
                totalGrossSales = gross,
                totalCommission = comm,
                netEarnings = net,
                completedOrdersCount = count,
                averageOrderValue = aov
            )
        }
    }

    private fun createDefaultProfile(): VendorProfile {
        return VendorProfile(
            id = "",
            name = "Quick Eats Partner Restaurant",
            description = "Gourmet dishes, signature fast food, and artisan refreshments.",
            cuisine = "Nigerian, Continental, Grills",
            address = "Victoria Island, Lagos, Nigeria",
            phone = "+234 800 000 0000",
            email = "vendor@quickeats.ng",
            rating = 4.8,
            totalReviews = 180,
            status = StoreStatus.OPEN,
            prepTimeMinutes = 20,
            commissionRatePercent = 15.0
        )
    }

    // Isolated sandbox seed data (clearly separated and only loaded on explicit sandbox choice)
    private fun seedSandboxData() {
        val now = System.currentTimeMillis()
        _vendorProfile.value = VendorProfile(
            id = "sandbox-vendor-001",
            name = "Jollof Express & Grills (Sandbox)",
            description = "Authentic smoky Nigerian party jollof, spicy peppered meats, and crispy sides.",
            cuisine = "Nigerian, Local, Fast Food",
            address = "24 Admiralty Way, Lekki Phase 1, Lagos",
            phone = "+234 802 345 6789",
            email = "demo-vendor@quickeats.ng",
            rating = 4.9,
            totalReviews = 412,
            status = StoreStatus.OPEN,
            prepTimeMinutes = 20,
            commissionRatePercent = 15.0
        )

        _categories.value = listOf(
            MenuCategory("cat-all", "All Items", 5),
            MenuCategory("cat-rice", "Jollof & Rice Bowls", 2),
            MenuCategory("cat-meats", "Grills & Peppered Meats", 2),
            MenuCategory("cat-drinks", "Chilled Drinks", 1)
        )

        _menuItems.value = listOf(
            MenuItem("sb-1", "sandbox-vendor-001", "cat-rice", "Signature Smoky Party Jollof", "Cooked with rich tomato plum broth, firewood aroma, plantain cubes.", 4500.0, "", true, false, true, 15),
            MenuItem("sb-2", "sandbox-vendor-001", "cat-rice", "Native Fried Rice with Shrimps", "Basmati rice wok-tossed with fresh tiger prawns, sweet peas, liver bits.", 6000.0, "", true, false, false, 20),
            MenuItem("sb-3", "sandbox-vendor-001", "cat-meats", "Jumbo Peppered Turkey Wings", "Deep fried golden and tossed in hot habanero and sweet bell pepper sauce.", 5500.0, "", true, false, true, 18),
            MenuItem("sb-4", "sandbox-vendor-001", "cat-meats", "Charcoal Grilled Suya Platter", "Thinly sliced prime beef dusted with traditional Yaji spice, onions, tomatoes.", 5000.0, "", true, false, true, 15),
            MenuItem("sb-5", "sandbox-vendor-001", "cat-drinks", "Fresh Zobo with Ginger & Pineapple", "Chilled hibiscus tea brewed with fresh ginger root, clove, and sweet pineapple.", 1500.0, "", true, true, false, 5)
        )

        val sandboxOrders = listOf(
            Order(
                id = "sb-ord-1",
                orderNumber = "#QE-4821",
                customerName = "Bolanle Williams",
                customerPhone = "+234 803 112 3344",
                deliveryAddress = "Block 4, Flat 12, Parkview Estate, Ikoyi",
                status = OrderStatus.PENDING,
                items = listOf(
                    OrderItem("sbi-1", "sb-1", "Signature Smoky Party Jollof", 2, 4500.0, "Extra dodo (fried plantain)"),
                    OrderItem("sbi-2", "sb-3", "Jumbo Peppered Turkey Wings", 1, 5500.0, "Very spicy sauce")
                ),
                subtotal = 14500.0,
                deliveryFee = 1500.0,
                tax = 500.0,
                platformFee = 2175.0,
                vendorEarnings = 12325.0,
                customerNote = "Call customer upon arrival at estate gate.",
                createdAt = now - (3 * 60 * 1000)
            ),
            Order(
                id = "sb-ord-2",
                orderNumber = "#QE-4819",
                customerName = "Emeka Okafor",
                customerPhone = "+234 812 445 6677",
                deliveryAddress = "15 Adeola Odeku St, Victoria Island",
                status = OrderStatus.PREPARING,
                items = listOf(
                    OrderItem("sbi-3", "sb-4", "Charcoal Grilled Suya Platter", 2, 5000.0, "Extra spicy yaji powder"),
                    OrderItem("sbi-4", "sb-5", "Fresh Zobo with Ginger", 2, 1500.0)
                ),
                subtotal = 13000.0,
                deliveryFee = 1200.0,
                tax = 450.0,
                platformFee = 1950.0,
                vendorEarnings = 11050.0,
                customerNote = "Leave at ground floor reception.",
                createdAt = now - (14 * 60 * 1000),
                rider = RiderInfo(
                    id = "sb-rd-1",
                    name = "Tunde Adeleke",
                    phone = "+234 809 334 5566",
                    vehicleType = "Bajaj Boxer 150 (Motorcycle)",
                    vehiclePlate = "IKJ-482-XA",
                    status = RiderStatus.ASSIGNED,
                    etaMinutes = 7
                )
            )
        )
        _orders.value = sandboxOrders
        knownOrderIds.addAll(sandboxOrders.map { it.id })
        calculateEarnings(sandboxOrders)
    }

    // Helper for testing audio alert in sandbox
    fun simulateSandboxIncomingOrder() {
        if (!_isSandboxMode.value) return
        val randomItem = _menuItems.value.randomOrNull() ?: return
        val orderNum = "#QE-${(5000..9999).random()}"
        val names = listOf("Kehinde Bankole", "Damilola Ade", "Chinedu Eze", "Amina Garba")
        val newOrder = Order(
            id = "sb-ord-${System.currentTimeMillis()}",
            orderNumber = orderNum,
            customerName = names.random(),
            customerPhone = "+234 80${(10000000..99999999).random()}",
            deliveryAddress = "Admiralty Way, Lekki",
            status = OrderStatus.PENDING,
            items = listOf(OrderItem(UUID.randomUUID().toString(), randomItem.id, randomItem.name, 1, randomItem.price)),
            subtotal = randomItem.price,
            deliveryFee = 1200.0,
            tax = 400.0,
            platformFee = randomItem.price * 0.15,
            vendorEarnings = randomItem.price * 0.85,
            customerNote = "Ring bell on outer gate.",
            createdAt = System.currentTimeMillis()
        )
        _orders.update { listOf(newOrder) + it }
        audioAlertManager.playNewOrderAlert()
        addNotification(
            title = "New Sandbox Order $orderNum",
            message = "New test order for ₦${String.format(Locale.US, "%,.2f", randomItem.price)}",
            type = "NEW_ORDER",
            orderId = newOrder.id
        )
    }
}
