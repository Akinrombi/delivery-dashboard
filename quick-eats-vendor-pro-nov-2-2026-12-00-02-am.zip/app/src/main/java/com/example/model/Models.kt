package com.example.model

import java.util.Locale

fun Double.toNairaString(): String = "₦" + String.format(Locale.US, "%,.2f", this)

enum class OrderStatus(val displayName: String, val apiValue: String) {
    PENDING("New Order", "pending"),
    ACCEPTED("Accepted", "accepted"),
    PREPARING("Preparing", "preparing"),
    READY_FOR_PICKUP("Ready for Rider", "ready_for_pickup"),
    COMPLETED("Completed", "completed"),
    CANCELLED("Cancelled", "cancelled");

    companion object {
        fun fromApi(value: String?): OrderStatus {
            return when (value?.lowercase()?.trim()) {
                "pending" -> PENDING
                "accepted" -> ACCEPTED
                "preparing" -> PREPARING
                "ready_for_pickup", "ready" -> READY_FOR_PICKUP
                "completed", "delivered" -> COMPLETED
                "cancelled", "declined" -> CANCELLED
                else -> PENDING
            }
        }
    }
}

enum class StoreStatus(val displayName: String, val apiValue: String) {
    OPEN("Open", "open"),
    BUSY("Busy (+15m)", "busy"),
    CLOSED("Closed", "closed");

    companion object {
        fun fromApi(value: String?): StoreStatus {
            return when (value?.lowercase()?.trim()) {
                "open" -> OPEN
                "busy" -> BUSY
                "closed" -> CLOSED
                else -> OPEN
            }
        }
    }
}

enum class RiderStatus(val displayName: String) {
    ASSIGNED("Rider Assigned"),
    AT_RESTAURANT("Arrived at Store"),
    PICKED_UP("Order Picked Up"),
    DELIVERED("Delivered")
}

data class RiderInfo(
    val id: String,
    val name: String,
    val phone: String,
    val vehicleType: String,
    val vehiclePlate: String,
    val status: RiderStatus,
    val etaMinutes: Int
)

data class OrderItem(
    val id: String,
    val menuItemId: String,
    val name: String,
    val quantity: Int,
    val unitPrice: Double,
    val options: String = "",
    val imageUrl: String = ""
) {
    val totalPrice: Double get() = quantity * unitPrice
}

data class Order(
    val id: String,
    val orderNumber: String,
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val status: OrderStatus,
    val items: List<OrderItem>,
    val subtotal: Double,
    val deliveryFee: Double = 1200.0,
    val tax: Double = 450.0,
    val platformFee: Double,
    val vendorEarnings: Double,
    val customerNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val prepTimeMinutes: Int = 20,
    val rider: RiderInfo? = null,
    val cancellationReason: String? = null
) {
    val totalAmount: Double get() = subtotal + deliveryFee + tax
    val itemCount: Int get() = items.sumOf { it.quantity }
}

data class MenuItem(
    val id: String,
    val vendorId: String,
    val categoryId: String,
    val name: String,
    val description: String,
    val price: Double,
    val imageUrl: String = "",
    val isAvailable: Boolean = true,
    val isVegetarian: Boolean = false,
    val isSpicy: Boolean = false,
    val prepTimeMinutes: Int = 15
)

data class MenuCategory(
    val id: String,
    val name: String,
    val itemCount: Int = 0
)

data class VendorProfile(
    val id: String,
    val name: String,
    val description: String,
    val cuisine: String,
    val address: String,
    val phone: String,
    val email: String,
    val rating: Double = 4.8,
    val totalReviews: Int = 342,
    val status: StoreStatus = StoreStatus.OPEN,
    val prepTimeMinutes: Int = 20,
    val commissionRatePercent: Double = 15.0,
    val isPaused: Boolean = false,
    val pausedUntil: Long? = null,
    val logoUrl: String = "",
    val bannerUrl: String = "",
    val openingHours: Map<String, String> = mapOf(
        "Monday" to "09:00 AM - 10:00 PM",
        "Tuesday" to "09:00 AM - 10:00 PM",
        "Wednesday" to "09:00 AM - 10:00 PM",
        "Thursday" to "09:00 AM - 10:00 PM",
        "Friday" to "09:00 AM - 11:30 PM",
        "Saturday" to "09:00 AM - 11:30 PM",
        "Sunday" to "10:00 AM - 09:30 PM"
    )
)

data class PayoutTransaction(
    val id: String,
    val reference: String,
    val amount: Double,
    val fee: Double,
    val netAmount: Double,
    val status: String, // "COMPLETED", "PROCESSING", "PENDING", "FAILED"
    val date: String,
    val bankAccountLast4: String,
    val bankName: String = "Zenith Bank"
)

data class VendorEarnings(
    val todaySales: Double,
    val weekSales: Double,
    val monthSales: Double,
    val totalGrossSales: Double,
    val totalCommission: Double,
    val netEarnings: Double,
    val completedOrdersCount: Int,
    val averageOrderValue: Double,
    val payouts: List<PayoutTransaction>
)

data class NotificationAlert(
    val id: String,
    val title: String,
    val message: String,
    val type: String, // "NEW_ORDER", "ORDER_CANCELLED", "RIDER_ASSIGNED", "RIDER_ARRIVED", "ORDER_COMPLETED"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val orderId: String? = null
)
