package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioAlertManager
import com.example.auth.AuthResult
import com.example.auth.RecoveryResult
import com.example.auth.VendorSession
import com.example.data.VendorRepository
import com.example.model.MenuItem
import com.example.model.MenuCategory
import com.example.model.NotificationAlert
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.StoreStatus
import com.example.model.VendorEarnings
import com.example.model.VendorProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VendorViewModel(
    val repository: VendorRepository,
    val audioAlertManager: AudioAlertManager
) : ViewModel() {

    val session: StateFlow<VendorSession?> = repository.session
    val isSandboxMode: StateFlow<Boolean> = repository.isSandboxMode
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val errorMessage: StateFlow<String?> = repository.errorMessage

    val vendorProfile: StateFlow<VendorProfile> = repository.vendorProfile
    val orders: StateFlow<List<Order>> = repository.orders
    val menuItems: StateFlow<List<MenuItem>> = repository.menuItems
    val categories: StateFlow<List<MenuCategory>> = repository.categories
    val earnings: StateFlow<VendorEarnings> = repository.earnings
    val notifications: StateFlow<List<NotificationAlert>> = repository.notifications
    val pauseBanner: StateFlow<String?> = repository.pauseBanner
    val isSupabaseConnected: StateFlow<Boolean> = repository.isSupabaseConnected
    val supabaseConfig = repository.supabaseConfig

    private val _orderSearchQuery = MutableStateFlow("")
    val orderSearchQuery: StateFlow<String> = _orderSearchQuery.asStateFlow()

    private val _selectedMenuCategory = MutableStateFlow("cat-all")
    val selectedMenuCategory: StateFlow<String> = _selectedMenuCategory.asStateFlow()

    private val _isSoundEnabled = MutableStateFlow(audioAlertManager.isSoundEnabled)
    val isSoundEnabled: StateFlow<Boolean> = _isSoundEnabled.asStateFlow()

    private val _isVibrationEnabled = MutableStateFlow(audioAlertManager.isVibrationEnabled)
    val isVibrationEnabled: StateFlow<Boolean> = _isVibrationEnabled.asStateFlow()

    // Filtered orders
    val pendingOrders: StateFlow<List<Order>> = orders.combine(_orderSearchQuery) { list, query ->
        list.filter { it.status == OrderStatus.PENDING && matchesQuery(it, query) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeOrders: StateFlow<List<Order>> = orders.combine(_orderSearchQuery) { list, query ->
        list.filter {
            (it.status == OrderStatus.ACCEPTED || it.status == OrderStatus.PREPARING || it.status == OrderStatus.READY_FOR_PICKUP) &&
                    matchesQuery(it, query)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedOrders: StateFlow<List<Order>> = orders.combine(_orderSearchQuery) { list, query ->
        list.filter { it.status == OrderStatus.COMPLETED && matchesQuery(it, query) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cancelledOrders: StateFlow<List<Order>> = orders.combine(_orderSearchQuery) { list, query ->
        list.filter { it.status == OrderStatus.CANCELLED && matchesQuery(it, query) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun matchesQuery(order: Order, query: String): Boolean {
        if (query.isBlank()) return true
        val lower = query.lowercase()
        return order.orderNumber.lowercase().contains(lower) ||
                order.customerName.lowercase().contains(lower) ||
                order.items.any { it.name.lowercase().contains(lower) }
    }

    // Filtered menu items
    val filteredMenuItems: StateFlow<List<MenuItem>> = menuItems.combine(_selectedMenuCategory) { items, catId ->
        if (catId == "cat-all") items else items.filter { it.categoryId == catId }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setOrderSearchQuery(query: String) {
        _orderSearchQuery.value = query
    }

    fun setSelectedMenuCategory(catId: String) {
        _selectedMenuCategory.value = catId
    }

    // Authentication
    suspend fun signIn(email: String, pass: String): AuthResult {
        return repository.signIn(email, pass)
    }

    suspend fun signUp(email: String, pass: String): AuthResult {
        return repository.signUp(email, pass)
    }

    suspend fun recoverPassword(email: String): RecoveryResult {
        return repository.recoverPassword(email)
    }

    fun logout() {
        repository.logout()
    }

    fun enterSandboxPreviewMode() {
        repository.enterSandboxPreviewMode()
    }

    fun refreshData() {
        repository.refreshData()
    }

    // Order Actions
    fun acceptOrder(orderId: String, prepMinutes: Int = 20) {
        repository.acceptOrder(orderId, prepMinutes)
    }

    fun rejectOrder(orderId: String, reason: String) {
        repository.rejectOrder(orderId, reason)
    }

    fun markOrderReady(orderId: String) {
        repository.markOrderReady(orderId)
    }

    fun markOrderCompleted(orderId: String) {
        repository.markOrderCompleted(orderId)
    }

    // Menu Actions
    fun toggleMenuItem(itemId: String, isAvailable: Boolean) {
        repository.toggleMenuItemAvailability(itemId, isAvailable)
    }

    fun saveMenuItem(item: MenuItem) {
        repository.saveMenuItem(item)
    }

    fun deleteMenuItem(itemId: String) {
        repository.deleteMenuItem(itemId)
    }

    fun pauseAllItems(minutes: Int, label: String) {
        repository.pauseAllItems(minutes, label)
    }

    fun restoreAllItems() {
        repository.restoreAllItems()
    }

    // Store Actions
    fun setStoreStatus(status: StoreStatus) {
        repository.setStoreStatus(status)
    }

    fun updateVendorProfile(profile: VendorProfile) {
        repository.updateVendorProfile(profile)
    }

    fun requestPayout(amount: Double) {
        repository.requestPayout(amount)
    }

    fun testAudioAlert() {
        audioAlertManager.playNewOrderAlert()
    }

    fun simulateSandboxIncomingOrder() {
        repository.simulateSandboxIncomingOrder()
    }

    fun toggleSound(enabled: Boolean) {
        audioAlertManager.isSoundEnabled = enabled
        _isSoundEnabled.value = enabled
    }

    fun toggleVibration(enabled: Boolean) {
        audioAlertManager.isVibrationEnabled = enabled
        _isVibrationEnabled.value = enabled
    }

    fun updateSupabaseConfig(url: String, key: String, vendorId: String) {
        repository.updateSupabaseConfig(url, key, vendorId)
    }

    fun markNotificationRead(id: String) {
        repository.markNotificationRead(id)
    }

    fun clearAllNotifications() {
        repository.clearAllNotifications()
    }
}
