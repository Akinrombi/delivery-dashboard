package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Moving
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PayoutTransaction
import com.example.model.toNairaString
import com.example.ui.components.MetricCard
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsGreen
import com.example.ui.theme.QuickEatsGreenContainer
import com.example.ui.theme.QuickEatsGreenDark
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeContainer
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.QuickEatsYellow
import com.example.ui.theme.QuickEatsYellowContainer
import com.example.ui.theme.QuickEatsYellowDark
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel
import java.util.Locale

@Composable
fun EarningsScreen(
    viewModel: VendorViewModel,
    modifier: Modifier = Modifier
) {
    val earnings by viewModel.earnings.collectAsState()
    var showPayoutDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceSlate)
            .testTag("earnings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Financial & Sales Overview",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = DarkSlate
                )
                Text(
                    text = "Real-time records from your Quick Eats partner ledger.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate
                )
            }
        }

        // Daily, Weekly, Monthly Sales Cards
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(
                    title = "Today's Gross Sales",
                    value = earnings.todaySales.toNairaString(),
                    subtitle = "Net Earnings: ${(earnings.todaySales * 0.85).toNairaString()}",
                    icon = Icons.Default.CalendarToday,
                    iconTint = QuickEatsGreenDark,
                    iconBgColor = QuickEatsGreenContainer,
                    testTag = "earnings_daily"
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Weekly Sales",
                        value = earnings.weekSales.toNairaString(),
                        subtitle = "Last 7 days",
                        icon = Icons.Default.DateRange,
                        iconTint = QuickEatsOrangeDark,
                        iconBgColor = QuickEatsOrangeContainer,
                        modifier = Modifier.weight(1f),
                        testTag = "earnings_weekly"
                    )

                    MetricCard(
                        title = "Monthly Sales",
                        value = earnings.monthSales.toNairaString(),
                        subtitle = "Current month",
                        icon = Icons.Default.TrendingUp,
                        iconTint = QuickEatsYellowDark,
                        iconBgColor = QuickEatsYellowContainer,
                        modifier = Modifier.weight(1f),
                        testTag = "earnings_monthly"
                    )
                }
            }
        }

        // Commission & Net Payout Breakdown Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Revenue & Commission Breakdown",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )

                        Box(
                            modifier = Modifier
                                .background(QuickEatsGreenContainer, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "15% Commission Rate",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = QuickEatsGreenDark
                            )
                        }
                    }

                    HorizontalDivider(color = BorderSlate, thickness = 1.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Total Lifetime Sales", style = MaterialTheme.typography.bodyMedium, color = MutedSlate)
                        Text(earnings.totalGrossSales.toNairaString(), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = DarkSlate)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Platform Service Commission (15%)", style = MaterialTheme.typography.bodyMedium, color = MutedSlate)
                        Text("-${earnings.totalCommission.toNairaString()}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = MutedSlate)
                    }

                    HorizontalDivider(color = BorderSlate, thickness = 1.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total Net Vendor Earnings",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkSlate
                            )
                            Text(
                                text = "Available for payout settlement",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedSlate
                            )
                        }

                        Text(
                            text = earnings.netEarnings.toNairaString(),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = QuickEatsGreenDark
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = { showPayoutDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("request_payout_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = QuickEatsOrange),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AccountBalance, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Request Payout Transfer", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Operational KPIs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Completed Orders", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                        Text(
                            text = "${earnings.completedOrdersCount}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Average Order Value (AOV)", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                        Text(
                            text = earnings.averageOrderValue.toNairaString(),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                    }
                }
            }
        }

        // Payout Settlements History
        item {
            Text(
                text = "Payout Settlement History",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkSlate
            )
        }

        items(earnings.payouts, key = { it.id }) { payout ->
            PayoutItemCard(payout)
        }
    }

    if (showPayoutDialog) {
        RequestPayoutDialog(
            maxAmount = earnings.netEarnings,
            onDismiss = { showPayoutDialog = false },
            onConfirm = { amount ->
                viewModel.requestPayout(amount)
                showPayoutDialog = false
            }
        )
    }
}

@Composable
fun PayoutItemCard(payout: PayoutTransaction) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(
                            if (payout.status == "COMPLETED") QuickEatsGreenContainer else QuickEatsYellowContainer,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (payout.status == "COMPLETED") Icons.Default.CheckCircle else Icons.Default.AccountBalance,
                        contentDescription = null,
                        tint = if (payout.status == "COMPLETED") QuickEatsGreenDark else QuickEatsYellowDark,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = payout.reference,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )
                    Text(
                        text = "${payout.date} • Bank acct ending in ${payout.bankAccountLast4}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSlate,
                        fontSize = 12.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = payout.netAmount.toNairaString(),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = DarkSlate
                )
                Box(
                    modifier = Modifier
                        .background(
                            if (payout.status == "COMPLETED") QuickEatsGreenContainer else QuickEatsYellowContainer,
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = payout.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (payout.status == "COMPLETED") QuickEatsGreenDark else QuickEatsYellowDark,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun RequestPayoutDialog(
    maxAmount: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var amountText by remember { mutableStateOf("50000") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = CardWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Request Settlement Payout",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = DarkSlate)
                    }
                }

                Text(
                    text = "Transfer earnings to your verified bank account (Zenith Bank • ending in 4820):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate
                )

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Payout Amount (₦)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Maximum available balance: ${maxAmount.toNairaString()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = QuickEatsGreenDark,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate)
                    ) {
                        Text("Cancel", color = DarkSlate)
                    }

                    Button(
                        onClick = {
                            val amount = amountText.toDoubleOrNull() ?: 0.0
                            if (amount > 0) {
                                onConfirm(amount)
                            }
                        },
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = QuickEatsGreen)
                    ) {
                        Text("Confirm Payout")
                    }
                }
            }
        }
    }
}
