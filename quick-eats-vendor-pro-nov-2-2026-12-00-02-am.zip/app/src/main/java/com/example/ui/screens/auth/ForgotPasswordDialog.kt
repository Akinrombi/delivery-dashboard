package com.example.ui.screens.auth

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.auth.RecoveryResult
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsGreenDark
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel
import kotlinx.coroutines.launch

@Composable
fun ForgotPasswordDialog(
    viewModel: VendorViewModel,
    onDismiss: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("forgot_password_dialog"),
            shape = RoundedCornerShape(20.dp),
            color = CardWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Reset Vendor Password",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )

                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = DarkSlate)
                    }
                }

                Text(
                    text = "Enter your registered QuickEats vendor email to receive a password reset link via Supabase Auth.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Vendor Email") },
                    placeholder = { Text("vendor@quickeats.ng") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = MutedSlate) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (statusMessage != null) {
                    Text(
                        text = statusMessage ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (isError) ErrorRed else QuickEatsGreenDark,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate)
                    ) {
                        Text("Cancel", color = DarkSlate)
                    }

                    Button(
                        onClick = {
                            if (email.isNotBlank()) {
                                isLoading = true
                                scope.launch {
                                    val result = viewModel.recoverPassword(email)
                                    isLoading = false
                                    when (result) {
                                        is RecoveryResult.Success -> {
                                            isError = false
                                            statusMessage = result.message
                                        }
                                        is RecoveryResult.Error -> {
                                            isError = true
                                            statusMessage = result.message
                                        }
                                    }
                                }
                            }
                        },
                        enabled = !isLoading && email.isNotBlank(),
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = QuickEatsOrange)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(color = CardWhite, strokeWidth = 2.dp, modifier = Modifier.height(18.dp))
                        } else {
                            Text("Send Link")
                        }
                    }
                }
            }
        }
    }
}
