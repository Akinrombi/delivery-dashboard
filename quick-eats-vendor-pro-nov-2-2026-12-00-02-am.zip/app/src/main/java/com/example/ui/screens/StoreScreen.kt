package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Surface
import androidx.compose.material3.IconButton
import androidx.compose.ui.window.Dialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.StoreStatus
import com.example.model.VendorProfile
import com.example.ui.components.SupabaseStatusDialog
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsGreen
import com.example.ui.theme.QuickEatsGreenContainer
import com.example.ui.theme.QuickEatsGreenDark
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeContainer
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.QuickEatsYellow
import com.example.ui.theme.QuickEatsYellowContainer
import com.example.ui.theme.QuickEatsYellowDark
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel

@Composable
fun StoreScreen(
    viewModel: VendorViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.vendorProfile.collectAsState()
    val isSoundEnabled by viewModel.isSoundEnabled.collectAsState()
    val isVibrationEnabled by viewModel.isVibrationEnabled.collectAsState()
    val isConnected by viewModel.isSupabaseConnected.collectAsState()
    val supabaseConfig by viewModel.supabaseConfig.collectAsState()

    var name by remember(profile) { mutableStateOf(profile.name) }
    var description by remember(profile) { mutableStateOf(profile.description) }
    var cuisine by remember(profile) { mutableStateOf(profile.cuisine) }
    var phone by remember(profile) { mutableStateOf(profile.phone) }
    var email by remember(profile) { mutableStateOf(profile.email) }
    var address by remember(profile) { mutableStateOf(profile.address) }
    var prepTime by remember(profile) { mutableStateOf(profile.prepTimeMinutes.toString()) }

    var savedMessage by remember { mutableStateOf<String?>(null) }
    var showBackendDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceSlate)
            .testTag("store_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Store & Kitchen Profile",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = DarkSlate
                )
                Text(
                    text = "Manage your restaurant information, operating hours, and alert settings.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate
                )
            }
        }

        // Store Status & Prep Time Quick Control Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "Store Operating Status",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StoreStatus.values().forEach { st ->
                            val isSelected = profile.status == st
                            val (bg, fg) = when (st) {
                                StoreStatus.OPEN -> Pair(QuickEatsGreen, CardWhite)
                                StoreStatus.BUSY -> Pair(QuickEatsYellow, DarkSlate)
                                StoreStatus.CLOSED -> Pair(DarkSlate, CardWhite)
                            }

                            Button(
                                onClick = { viewModel.setStoreStatus(st) },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) bg else SurfaceSlate
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = st.displayName.split(" ").first(),
                                    color = if (isSelected) fg else DarkSlate,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = BorderSlate, thickness = 1.dp)

                    Text(
                        text = "Default Kitchen Preparation Time",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(15, 20, 30, 45).forEach { mins ->
                            val isSelected = (prepTime.toIntOrNull() ?: 20) == mins
                            OutlinedButton(
                                onClick = { prepTime = mins.toString() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) QuickEatsOrangeContainer else CardWhite,
                                    contentColor = if (isSelected) QuickEatsOrangeDark else DarkSlate
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("${mins}m", fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }

        // Audio & Kitchen Alerts Configuration Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kitchen Audio & Sound Alerts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )

                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = QuickEatsOrange)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = DarkSlate, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Loud Order Chime Sound", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Plays ringtone when order arrives", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                            }
                        }

                        Switch(
                            checked = isSoundEnabled,
                            onCheckedChange = { viewModel.toggleSound(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CardWhite,
                                checkedTrackColor = QuickEatsOrange
                            )
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = null, tint = DarkSlate, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Device Kitchen Vibration", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Vibrates for order updates & pickups", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                            }
                        }

                        Switch(
                            checked = isVibrationEnabled,
                            onCheckedChange = { viewModel.toggleVibration(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CardWhite,
                                checkedTrackColor = QuickEatsOrange
                            )
                        )
                    }

                    Button(
                        onClick = { viewModel.testAudioAlert() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = QuickEatsOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Kitchen Chime Sound Now", color = DarkSlate, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Restaurant Details Editor
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Restaurant Profile Details",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkSlate
                    )

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Restaurant Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("store_name_input")
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("About Restaurant") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = cuisine,
                        onValueChange = { cuisine = it },
                        label = { Text("Cuisine Tags") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Phone") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Email") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Kitchen Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (savedMessage != null) {
                        Text(
                            text = savedMessage ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = QuickEatsGreenDark,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val updated = profile.copy(
                                name = name,
                                description = description,
                                cuisine = cuisine,
                                phone = phone,
                                email = email,
                                address = address,
                                prepTimeMinutes = prepTime.toIntOrNull() ?: 20
                            )
                            viewModel.updateVendorProfile(updated)
                            savedMessage = "✓ Profile details updated successfully!"
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_store_profile_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = QuickEatsOrange),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Profile Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Weekly Operating Hours Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = DarkSlate, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Operating Hours Schedule",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkSlate
                            )
                        }
                    }

                    profile.openingHours.forEach { (day, hours) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = day, style = MaterialTheme.typography.bodyMedium, color = DarkSlate, fontWeight = FontWeight.Medium)
                            Text(text = hours, style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                        }
                    }
                }
            }
        }

        // Supabase Backend Integration Details
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isConnected) Icons.Default.CloudDone else Icons.Default.Cloud,
                                contentDescription = null,
                                tint = if (isConnected) QuickEatsGreenDark else QuickEatsOrange,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Supabase Database & API",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkSlate
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(if (isConnected) QuickEatsGreenContainer else SurfaceSlate, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isConnected) "Connected" else "Standby Mode",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isConnected) QuickEatsGreenDark else MutedSlate
                            )
                        }
                    }

                    Text(
                        text = "Vendor ID: ${profile.id} • Commission: ${profile.commissionRatePercent}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSlate
                    )

                    Button(
                        onClick = { showBackendDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Configure Supabase Project & Anon Key", color = DarkSlate, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Help & Support Card (Phase 9)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HelpOutline, contentDescription = null, tint = QuickEatsOrange, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Vendor Partner Support",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                    }

                    Text(
                        text = "Need assistance with order disputes, rider delays, or payouts? Contact your dedicated partner manager:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSlate
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Partner Email:", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                        Text("partners@quickeats.ng", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = DarkSlate)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Merchant Hotline:", style = MaterialTheme.typography.bodySmall, color = MutedSlate)
                        Text("+234 1 800 3287", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = DarkSlate)
                    }
                }
            }
        }

        // App Version & Legal Info (Phase 9)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Quick Eats Vendor App • v1.4.2 Production",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate,
                    fontSize = 12.sp
                )
                Text(
                    text = "Lagos, Nigeria • All Rights Reserved",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedSlate,
                    fontSize = 11.sp
                )
            }
        }

        // Secure Logout Button (Phase 9)
        item {
            OutlinedButton(
                onClick = { viewModel.logout() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 24.dp)
                    .testTag("vendor_logout_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = com.example.ui.theme.ErrorRed)
            ) {
                Icon(Icons.Default.ExitToApp, contentDescription = null, tint = com.example.ui.theme.ErrorRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Secure Logout", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showBackendDialog) {
        SupabaseStatusDialog(
            config = supabaseConfig,
            isConnected = isConnected,
            onDismiss = { showBackendDialog = false },
            onSaveConfig = { url, key, vendorId ->
                viewModel.updateSupabaseConfig(url, key, vendorId)
            }
        )
    }
}
