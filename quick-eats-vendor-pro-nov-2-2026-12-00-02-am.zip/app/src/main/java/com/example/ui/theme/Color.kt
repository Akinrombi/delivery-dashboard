package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Quick Eats Brand Palette
val QuickEatsOrange = Color(0xFFFF6B00)
val QuickEatsOrangeDark = Color(0xFFD95300)
val QuickEatsOrangeLight = Color(0xFFFF8B3D)
val QuickEatsOrangeContainer = Color(0xFFFFF0E6)

val QuickEatsGreen = Color(0xFF10B981)
val QuickEatsGreenDark = Color(0xFF059669)
val QuickEatsGreenLight = Color(0xFF34D399)
val QuickEatsGreenContainer = Color(0xFFECFDF5)

val QuickEatsYellow = Color(0xFFF59E0B)
val QuickEatsYellowDark = Color(0xFFD97706)
val QuickEatsYellowLight = Color(0xFFFBBF24)
val QuickEatsYellowContainer = Color(0xFFFEF3C7)

val DarkSlate = Color(0xFF0F172A)
val Charcoal = Color(0xFF1E293B)
val MutedSlate = Color(0xFF64748B)
val LightSlate = Color(0xFF94A3B8)
val BorderSlate = Color(0xFFE2E8F0)
val SurfaceSlate = Color(0xFFF8FAFC)
val CardWhite = Color(0xFFFFFFFF)

val ErrorRed = Color(0xFFEF4444)
val ErrorContainer = Color(0xFFFEE2E2)
val ErrorText = Color(0xFFB91C1C)
