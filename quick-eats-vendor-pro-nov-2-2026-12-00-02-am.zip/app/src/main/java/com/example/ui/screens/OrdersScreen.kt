package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.ui.components.OrderCard
import com.example.ui.components.OrderDetailDialog
import com.example.ui.components.RejectionDialog
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel

@Composable
fun OrdersScreen(
    viewModel: VendorViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val searchQuery by viewModel.orderSearchQuery.collectAsState()

    val pendingOrders by viewModel.pendingOrders.collectAsState()
    val activeOrders by viewModel.activeOrders.collectAsState()
    val completedOrders by viewModel.completedOrders.collectAsState()
    val cancelledOrders by viewModel.cancelledOrders.collectAsState()

    var selectedOrderForDetail by remember { mutableStateOf<Order?>(null) }
    var selectedOrderForReject by remember { mutableStateOf<Order?>(null) }

    val tabs = listOf(
        "Pending (${pendingOrders.size})",
        "Kitchen (${activeOrders.size})",
        "Completed (${completedOrders.size})",
        "Cancelled (${cancelledOrders.size})"
    )

    val currentList = when (selectedTabIndex) {
        0 -> pendingOrders
        1 -> activeOrders
        2 -> completedOrders
        else -> cancelledOrders
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceSlate)
            .testTag("orders_screen")
    ) {
        // Search Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardWhite)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                text = "Order Management",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = DarkSlate
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setOrderSearchQuery(it) },
                placeholder = { Text("Search by Order #, Customer, or Item...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = MutedSlate)
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { viewModel.setOrderSearchQuery("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MutedSlate)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("order_search_input")
            )
        }

        // Tab Navigation
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = CardWhite,
            contentColor = QuickEatsOrange,
            edgePadding = 16.dp
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                            color = if (selectedTabIndex == index) QuickEatsOrangeDark else MutedSlate,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        // Orders List
        if (currentList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassEmpty,
                            contentDescription = null,
                            tint = MutedSlate.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No orders in this status",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                        Text(
                            text = if (searchQuery.isNotBlank()) "No orders match \"$searchQuery\"." else "Orders will appear here as they progress through the kitchen pipeline.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedSlate,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(currentList, key = { it.id }) { order ->
                    OrderCard(
                        order = order,
                        onAccept = { prepMins -> viewModel.acceptOrder(order.id, prepMins) },
                        onReject = { selectedOrderForReject = order },
                        onMarkReady = { viewModel.markOrderReady(order.id) },
                        onMarkCompleted = { viewModel.markOrderCompleted(order.id) },
                        onClick = { selectedOrderForDetail = order }
                    )
                }
            }
        }
    }

    // Order Detail Modal
    selectedOrderForDetail?.let { order ->
        OrderDetailDialog(
            order = order,
            onDismiss = { selectedOrderForDetail = null },
            onAccept = { viewModel.acceptOrder(order.id) },
            onMarkReady = { viewModel.markOrderReady(order.id) },
            onMarkCompleted = { viewModel.markOrderCompleted(order.id) },
            onReject = { selectedOrderForReject = order }
        )
    }

    // Rejection Modal
    selectedOrderForReject?.let { order ->
        RejectionDialog(
            order = order,
            onDismiss = { selectedOrderForReject = null },
            onConfirmReject = { reason ->
                viewModel.rejectOrder(order.id, reason)
                selectedOrderForReject = null
            }
        )
    }
}
