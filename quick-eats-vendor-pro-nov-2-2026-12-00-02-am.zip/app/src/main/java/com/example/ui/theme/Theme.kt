package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = QuickEatsOrange,
    onPrimary = CardWhite,
    primaryContainer = QuickEatsOrangeContainer,
    onPrimaryContainer = QuickEatsOrangeDark,
    secondary = QuickEatsGreen,
    onSecondary = CardWhite,
    secondaryContainer = QuickEatsGreenContainer,
    onSecondaryContainer = QuickEatsGreenDark,
    tertiary = QuickEatsYellow,
    onTertiary = DarkSlate,
    tertiaryContainer = QuickEatsYellowContainer,
    onTertiaryContainer = QuickEatsYellowDark,
    background = SurfaceSlate,
    onBackground = DarkSlate,
    surface = CardWhite,
    onSurface = DarkSlate,
    surfaceVariant = SurfaceSlate,
    onSurfaceVariant = MutedSlate,
    outline = BorderSlate,
    error = ErrorRed,
    errorContainer = ErrorContainer,
    onError = CardWhite,
    onErrorContainer = ErrorText
)

private val DarkColorScheme = darkColorScheme(
    primary = QuickEatsOrangeLight,
    onPrimary = DarkSlate,
    primaryContainer = QuickEatsOrangeDark,
    onPrimaryContainer = CardWhite,
    secondary = QuickEatsGreenLight,
    onSecondary = DarkSlate,
    secondaryContainer = QuickEatsGreenDark,
    onSecondaryContainer = CardWhite,
    tertiary = QuickEatsYellowLight,
    onTertiary = DarkSlate,
    tertiaryContainer = QuickEatsYellowDark,
    onTertiaryContainer = CardWhite,
    background = DarkSlate,
    onBackground = CardWhite,
    surface = Charcoal,
    onSurface = CardWhite,
    surfaceVariant = Charcoal,
    onSurfaceVariant = LightSlate,
    outline = MutedSlate,
    error = ErrorRed,
    errorContainer = ErrorContainer,
    onError = CardWhite,
    onErrorContainer = ErrorText
)

@Composable
fun QuickEatsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(it, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    QuickEatsTheme(darkTheme = darkTheme, content = content)
}
