package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DirectionsBike
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.RiderStatus
import com.example.model.toNairaString
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CardWhite
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.ErrorContainer
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorText
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsGreen
import com.example.ui.theme.QuickEatsGreenContainer
import com.example.ui.theme.SurfaceSlate
import com.example.ui.theme.QuickEatsGreenDark
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeContainer
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.QuickEatsYellow
import com.example.ui.theme.QuickEatsYellowContainer
import com.example.ui.theme.QuickEatsYellowDark
import java.util.Locale

@Composable
fun OrderCard(
    order: Order,
    onAccept: (prepMinutes: Int) -> Unit,
    onReject: () -> Unit,
    onMarkReady: () -> Unit,
    onMarkCompleted: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showPrepOptions by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("order_card_${order.id}")
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Order Number, Time elapsed, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = order.orderNumber,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        val elapsedMinutes = ((System.currentTimeMillis() - order.createdAt) / 60000).coerceAtLeast(0)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = MutedSlate,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${elapsedMinutes}m ago",
                                style = MaterialTheme.typography.bodySmall,
                                color = MutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Text(
                        text = "${order.customerName} • ${order.itemCount} items",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedSlate
                    )
                }

                OrderStatusBadge(order.status)
            }

            HorizontalDivider(color = BorderSlate, thickness = 1.dp)

            // Items Summary
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                order.items.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${item.quantity}x ${item.name}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = DarkSlate
                            )
                            if (item.options.isNotBlank()) {
                                Text(
                                    text = "• ${item.options}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedSlate,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Text(
                            text = item.totalPrice.toNairaString(),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = DarkSlate
                        )
                    }
                }
            }

            // Customer Special Instructions Callout
            if (order.customerNote.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(QuickEatsYellowContainer.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .border(1.dp, QuickEatsYellowDark.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Note",
                            tint = QuickEatsYellowDark,
                            modifier = Modifier
                                .size(16.dp)
                                .padding(top = 1.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = order.customerNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkSlate,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Assigned Rider Status (if active)
            if (order.rider != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(QuickEatsGreenContainer.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(QuickEatsGreen, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.DirectionsBike,
                                    contentDescription = null,
                                    tint = CardWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Rider: ${order.rider.name}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkSlate
                                )
                                Text(
                                    text = "${order.rider.vehicleType} (${order.rider.vehiclePlate})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MutedSlate,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .background(CardWhite, RoundedCornerShape(12.dp))
                                .border(1.dp, QuickEatsGreenDark, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (order.rider.etaMinutes > 0) "ETA ${order.rider.etaMinutes}m" else "At Restaurant",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = QuickEatsGreenDark
                            )
                        }
                    }
                }
            }

            // Financial Summary (Total & Vendor Net Earnings)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Subtotal: ${order.subtotal.toNairaString()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedSlate
                    )
                }
                Text(
                    text = "Your Net: ${order.vendorEarnings.toNairaString()}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = QuickEatsGreenDark
                )
            }

            // Action Buttons based on order state
            when (order.status) {
                OrderStatus.PENDING -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = onReject,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("decline_order_button"),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(ErrorRed))
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Decline")
                            }

                            Button(
                                onClick = { onAccept(order.prepTimeMinutes) },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("accept_order_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = QuickEatsOrange)
                            ) {
                                Icon(Icons.Default.Restaurant, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Accept (${order.prepTimeMinutes}m)")
                            }
                        }

                        // Prep time customization toggle
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showPrepOptions = !showPrepOptions },
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (showPrepOptions) "Hide prep time options" else "Change prep time (15m, 20m, 30m)",
                                style = MaterialTheme.typography.labelSmall,
                                color = QuickEatsOrangeDark,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        AnimatedVisibility(visible = showPrepOptions) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(15, 20, 30, 45).forEach { mins ->
                                    OutlinedButton(
                                        onClick = { onAccept(mins) },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (order.prepTimeMinutes == mins) QuickEatsOrangeDark else MutedSlate
                                        )
                                    ) {
                                        Text("${mins}m", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                OrderStatus.ACCEPTED, OrderStatus.PREPARING -> {
                    Button(
                        onClick = onMarkReady,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ready_for_pickup_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = QuickEatsGreen)
                    ) {
                        Icon(Icons.Default.DeliveryDining, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Mark Ready for Rider Pickup")
                    }
                }

                OrderStatus.READY_FOR_PICKUP -> {
                    Button(
                        onClick = onMarkCompleted,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_picked_up_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSlate)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm Handed Over to Rider")
                    }
                }

                OrderStatus.COMPLETED -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceSlate, RoundedCornerShape(8.dp))
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "✓ Order Delivered & Settled",
                            style = MaterialTheme.typography.bodySmall,
                            color = QuickEatsGreenDark,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                OrderStatus.CANCELLED -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ErrorContainer, RoundedCornerShape(8.dp))
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Cancelled: ${order.cancellationReason ?: "Declined by kitchen"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = ErrorText,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OrderStatusBadge(status: OrderStatus) {
    val (bgColor, textColor, label) = when (status) {
        OrderStatus.PENDING -> Triple(QuickEatsOrangeContainer, QuickEatsOrangeDark, "Action Required")
        OrderStatus.ACCEPTED -> Triple(QuickEatsYellowContainer, QuickEatsYellowDark, "Accepted")
        OrderStatus.PREPARING -> Triple(QuickEatsYellowContainer, QuickEatsYellowDark, "Preparing")
        OrderStatus.READY_FOR_PICKUP -> Triple(QuickEatsGreenContainer, QuickEatsGreenDark, "Ready for Rider")
        OrderStatus.COMPLETED -> Triple(BorderSlate, DarkSlate, "Completed")
        OrderStatus.CANCELLED -> Triple(ErrorContainer, ErrorText, "Cancelled")
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}
