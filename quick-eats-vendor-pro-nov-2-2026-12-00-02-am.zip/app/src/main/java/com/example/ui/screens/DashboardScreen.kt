package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.StoreStatus
import com.example.model.toNairaString
import com.example.ui.components.MetricCard
import com.example.ui.components.OrderCard
import com.example.ui.components.OrderDetailDialog
import com.example.ui.components.RejectionDialog
import com.example.ui.components.SupabaseStatusDialog
import com.example.ui.components.UrgentPendingOrderBanner
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CardWhite
import com.example.ui.theme.Charcoal
import com.example.ui.theme.DarkSlate
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.QuickEatsGreen
import com.example.ui.theme.QuickEatsGreenContainer
import com.example.ui.theme.QuickEatsGreenDark
import com.example.ui.theme.QuickEatsOrange
import com.example.ui.theme.QuickEatsOrangeContainer
import com.example.ui.theme.QuickEatsOrangeDark
import com.example.ui.theme.QuickEatsYellow
import com.example.ui.theme.QuickEatsYellowContainer
import com.example.ui.theme.QuickEatsYellowDark
import com.example.ui.theme.SurfaceSlate
import com.example.viewmodel.VendorViewModel
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: VendorViewModel,
    onNavigateToOrders: () -> Unit,
    onOpenNotifications: () -> Unit,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.vendorProfile.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val pendingOrders by viewModel.pendingOrders.collectAsState()
    val earnings by viewModel.earnings.collectAsState()
    val pauseBanner by viewModel.pauseBanner.collectAsState()
    val isConnected by viewModel.isSupabaseConnected.collectAsState()
    val supabaseConfig by viewModel.supabaseConfig.collectAsState()
    val isSandbox by viewModel.isSandboxMode.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    var selectedOrderForDetail by remember { mutableStateOf<Order?>(null) }
    var selectedOrderForReject by remember { mutableStateOf<Order?>(null) }
    var showBackendDialog by remember { mutableStateOf(false) }
    var showPauseMenu by remember { mutableStateOf(false) }

    val preparingOrders = orders.filter { it.status == OrderStatus.PREPARING || it.status == OrderStatus.ACCEPTED }
    val readyOrders = orders.filter { it.status == OrderStatus.READY_FOR_PICKUP }
    val completedOrders = orders.filter { it.status == OrderStatus.COMPLETED }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceSlate)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)
    ) {
        // Hero Store Banner with Status selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.quick_eats_hero),
                            contentDescription = "Kitchen Cover",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, DarkSlate.copy(alpha = 0.8f))
                                    )
                                )
                        )

                        // Top Controls inside Hero
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Supabase status pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(CardWhite.copy(alpha = 0.9f))
                                    .clickable { showBackendDialog = true }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isConnected) Icons.Default.CloudDone else Icons.Default.Cloud,
                                        contentDescription = null,
                                        tint = if (isConnected) QuickEatsGreenDark else QuickEatsOrange,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isConnected) "Supabase Live" else "Local Standby",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = DarkSlate,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            // Notification & Sound Bell
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { viewModel.refreshData() },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(CardWhite.copy(alpha = 0.9f), CircleShape)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Refresh live data", tint = QuickEatsGreenDark, modifier = Modifier.size(18.dp))
                                }

                                IconButton(
                                    onClick = { viewModel.testAudioAlert() },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(CardWhite.copy(alpha = 0.9f), CircleShape)
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Test buzzer", tint = QuickEatsOrange, modifier = Modifier.size(18.dp))
                                }

                                IconButton(
                                    onClick = onOpenNotifications,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(CardWhite.copy(alpha = 0.9f), CircleShape)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = "Alerts", tint = DarkSlate, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Store Name & Rating in Hero Bottom
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = profile.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CardWhite
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = QuickEatsYellow, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "${profile.rating} (${profile.totalReviews}) • ${profile.cuisine}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CardWhite.copy(alpha = 0.9f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    // Store Operating Status Switcher
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kitchen Status:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StoreStatus.values().forEach { st ->
                                val isSelected = profile.status == st
                                val (activeBg, activeFg) = when (st) {
                                    StoreStatus.OPEN -> Pair(QuickEatsGreen, CardWhite)
                                    StoreStatus.BUSY -> Pair(QuickEatsYellow, DarkSlate)
                                    StoreStatus.CLOSED -> Pair(DarkSlate, CardWhite)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (isSelected) activeBg else SurfaceSlate)
                                        .border(
                                            width = if (isSelected) 0.dp else 1.dp,
                                            color = BorderSlate,
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                        .clickable { viewModel.setStoreStatus(st) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = st.displayName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) activeFg else MutedSlate,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Emergency Pause Banner (if active)
        if (pauseBanner != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = QuickEatsYellowContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PauseCircle, contentDescription = null, tint = QuickEatsYellowDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = pauseBanner ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkSlate
                            )
                        }

                        Button(
                            onClick = { viewModel.restoreAllItems() },
                            colors = ButtonDefaults.buttonColors(containerColor = QuickEatsGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Resume All", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Urgent Pending Orders Banner (with 1-tap accept and sound cue)
        item {
            UrgentPendingOrderBanner(
                pendingOrders = pendingOrders,
                onAcceptOrder = { orderId -> viewModel.acceptOrder(orderId) },
                onViewAllPending = onNavigateToOrders
            )
        }

        // Action banner (Sandbox test order or Live refresh)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isSandbox) {
                    OutlinedButton(
                        onClick = { viewModel.simulateSandboxIncomingOrder() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("simulate_order_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Restaurant, contentDescription = null, tint = QuickEatsOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Sandbox Order", color = QuickEatsOrangeDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = { viewModel.refreshData() },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("refresh_live_orders_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = QuickEatsGreenDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Refresh Live Orders", color = DarkSlate, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedButton(
                    onClick = { showPauseMenu = !showPauseMenu },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PauseCircle, contentDescription = null, tint = MutedSlate, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Pause Orders", color = DarkSlate, fontSize = 12.sp)
                }
            }
        }

        // Quick Pause Options
        if (showPauseMenu) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Pause incoming kitchen orders for:", style = MaterialTheme.typography.labelMedium, color = MutedSlate)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                Pair(30, "30 mins"),
                                Pair(60, "1 hour"),
                                Pair(1440, "Until tomorrow")
                            ).forEach { (mins, label) ->
                                Button(
                                    onClick = {
                                        viewModel.pauseAllItems(mins, label)
                                        showPauseMenu = false
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceSlate),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(label, color = DarkSlate, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Financial & Orders KPI Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Today's Performance",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkSlate
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Gross Sales",
                        value = earnings.todaySales.toNairaString(),
                        subtitle = "Net: ${(earnings.todaySales * 0.85).toNairaString()}",
                        icon = Icons.Default.AttachMoney,
                        iconTint = QuickEatsGreenDark,
                        iconBgColor = QuickEatsGreenContainer,
                        modifier = Modifier.weight(1f),
                        testTag = "metric_gross_sales"
                    )

                    MetricCard(
                        title = "Today's Orders",
                        value = "${orders.size}",
                        subtitle = "${completedOrders.size} delivered",
                        icon = Icons.Default.Receipt,
                        iconTint = QuickEatsOrange,
                        iconBgColor = QuickEatsOrangeContainer,
                        modifier = Modifier.weight(1f),
                        testTag = "metric_today_orders"
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Pending Action",
                        value = "${pendingOrders.size}",
                        subtitle = if (pendingOrders.isNotEmpty()) "Urgent: Accept now" else "All caught up",
                        icon = Icons.Default.Restaurant,
                        iconTint = if (pendingOrders.isNotEmpty()) QuickEatsOrangeDark else MutedSlate,
                        iconBgColor = if (pendingOrders.isNotEmpty()) QuickEatsOrangeContainer else SurfaceSlate,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToOrders,
                        testTag = "metric_pending_orders"
                    )

                    MetricCard(
                        title = "Preparing / Ready",
                        value = "${preparingOrders.size + readyOrders.size}",
                        subtitle = "${readyOrders.size} awaiting rider",
                        icon = Icons.Default.DeliveryDining,
                        iconTint = QuickEatsYellowDark,
                        iconBgColor = QuickEatsYellowContainer,
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToOrders,
                        testTag = "metric_in_kitchen"
                    )
                }
            }
        }

        // Active Orders Live Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Kitchen Queue",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkSlate
                )

                Text(
                    text = "View All (${orders.size})",
                    style = MaterialTheme.typography.labelMedium,
                    color = QuickEatsOrangeDark,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateToOrders() }
                )
            }
        }

        val activeList = orders.filter { it.status != OrderStatus.COMPLETED && it.status != OrderStatus.CANCELLED }

        if (activeList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardWhite)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = QuickEatsGreen,
                            modifier = Modifier.size(42.dp)
                        )
                        Text(
                            text = "Kitchen is Clear!",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkSlate
                        )
                        Text(
                            text = "No active orders waiting. When a customer orders, an audible alert will sound.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedSlate,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(activeList, key = { it.id }) { order ->
                OrderCard(
                    order = order,
                    onAccept = { prepMins -> viewModel.acceptOrder(order.id, prepMins) },
                    onReject = { selectedOrderForReject = order },
                    onMarkReady = { viewModel.markOrderReady(order.id) },
                    onMarkCompleted = { viewModel.markOrderCompleted(order.id) },
                    onClick = { selectedOrderForDetail = order }
                )
            }
        }
    }

    // Order Detail Modal
    selectedOrderForDetail?.let { order ->
        OrderDetailDialog(
            order = order,
            onDismiss = { selectedOrderForDetail = null },
            onAccept = { viewModel.acceptOrder(order.id) },
            onMarkReady = { viewModel.markOrderReady(order.id) },
            onMarkCompleted = { viewModel.markOrderCompleted(order.id) },
            onReject = { selectedOrderForReject = order }
        )
    }

    // Rejection Modal
    selectedOrderForReject?.let { order ->
        RejectionDialog(
            order = order,
            onDismiss = { selectedOrderForReject = null },
            onConfirmReject = { reason ->
                viewModel.rejectOrder(order.id, reason)
                selectedOrderForReject = null
            }
        )
    }

    // Supabase Status Dialog
    if (showBackendDialog) {
        SupabaseStatusDialog(
            config = supabaseConfig,
            isConnected = isConnected,
            onDismiss = { showBackendDialog = false },
            onSaveConfig = { url, key, vendorId ->
                viewModel.updateSupabaseConfig(url, key, vendorId)
            }
        )
    }
}
